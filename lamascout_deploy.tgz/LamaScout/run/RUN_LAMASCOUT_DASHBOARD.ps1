<#
.SYNOPSIS
    LamaScout Artist Intelligence Dashboard Launcher
    Port 5017 · Panel + Plotly · φ-harmonic scoring

.DESCRIPTION
    Starts the LamaScout Panel dashboard for artist breakout discovery.
    Mirrors the institutional crypto trading dashboard aesthetic and engine design.

.EXAMPLE
    .\RUN_LAMASCOUT_DASHBOARD.ps1
    .\RUN_LAMASCOUT_DASHBOARD.ps1 -ExportHTML
    .\RUN_LAMASCOUT_DASHBOARD.ps1 -Port 5018
#>
param(
    [int]   $Port      = 5017,
    [switch]$ExportHTML
)

$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

$VENV_PYTHON = "C:\LumaTrader\INSTITUTIONAL_STACK_V2\code\.venv\Scripts\python.exe"
$SCOUT_ROOT  = "C:\LumaTrader\INSTITUTIONAL_STACK_V2\LamaScout"
$DASHBOARD   = "$SCOUT_ROOT\src\lamascout_dashboard.py"

Write-Host ""
Write-Host "  ██╗      █████╗ ███╗   ███╗ █████╗ ███████╗ ██████╗ ██████╗ ██╗   ██╗████████╗" -ForegroundColor Magenta
Write-Host "  ██║     ██╔══██╗████╗ ████║██╔══██╗██╔════╝██╔════╝██╔═══██╗██║   ██║╚══██╔══╝" -ForegroundColor Magenta
Write-Host "  ██║     ███████║██╔████╔██║███████║███████╗██║     ██║   ██║██║   ██║   ██║   " -ForegroundColor Magenta
Write-Host "  ██║     ██╔══██║██║╚██╔╝██║██╔══██║╚════██║██║     ██║   ██║██║   ██║   ██║   " -ForegroundColor Magenta
Write-Host "  ███████╗██║  ██║██║ ╚═╝ ██║██║  ██║███████║╚██████╗╚██████╔╝╚██████╔╝   ██║   " -ForegroundColor Magenta
Write-Host "  ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝  ╚═════╝    ╚═╝  " -ForegroundColor Magenta
Write-Host ""
Write-Host "  Artist Intelligence Dashboard  ·  φ = 1.6180339887  ·  Port $Port" -ForegroundColor Cyan
Write-Host ""

if (-not (Test-Path $VENV_PYTHON)) {
    Write-Host "[ERROR] venv python not found: $VENV_PYTHON" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $DASHBOARD)) {
    Write-Host "[ERROR] Dashboard not found: $DASHBOARD" -ForegroundColor Red
    exit 1
}

# ── optional static HTML export before serving ─────────────────────────────
if ($ExportHTML) {
    Write-Host "[LamaScout] Exporting static HTML snapshot..." -ForegroundColor Yellow
    & $VENV_PYTHON $DASHBOARD
    Write-Host "[LamaScout] HTML export complete." -ForegroundColor Green
}

# ── launch Panel serve ─────────────────────────────────────────────────────
Write-Host "[LamaScout] Starting dashboard on http://localhost:$Port" -ForegroundColor Green
Write-Host "[LamaScout] Allow all origins for VPS reverse proxy compatibility" -ForegroundColor DarkGray
Write-Host ""

& $VENV_PYTHON -m panel serve `
    $DASHBOARD `
    --port $Port `
    --allow-websocket-origin="*" `
    --autoreload `
    --address="0.0.0.0" `
    --show
