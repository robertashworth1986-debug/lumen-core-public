$ErrorActionPreference = "Stop"

$ROOT = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location "$ROOT\.."
$PY = "c:\LumaTrader\INSTITUTIONAL_STACK_V2\.venv\Scripts\python.exe"

if (-not (Test-Path $PY)) {
    Write-Error "Python executable not found at $PY. Activate the virtual environment or update the path."
    exit 1
}

Write-Host "[LumaScout NextLevel] Installing dependencies if needed..."
& $PY -m pip install -r requirements.txt | Out-Null

Write-Host "[LumaScout NextLevel] Running pipeline..."
& $PY -m src.artist_scout_engine

Write-Host "[LumaScout NextLevel] Starting dashboard API in the background..."
$apiArgs = "-m uvicorn src.dashboard_api:app --host 0.0.0.0 --port 8000 --reload"
$apiProcess = Start-Process -FilePath $PY -ArgumentList $apiArgs -WindowStyle Minimized -PassThru

Write-Host "[LumaScout NextLevel] Waiting for API health check..."
$serviceReady = $false
for ($i = 0; $i -lt 15; $i++) {
    try {
        $response = Invoke-RestMethod -Uri "http://127.0.0.1:8000/health" -Method Get -TimeoutSec 5
        if ($response.status -eq "ok") {
            $serviceReady = $true
            break
        }
    } catch {
        Start-Sleep -Seconds 2
    }
}

if (-not $serviceReady) {
    Write-Error "Dashboard API did not start in time. Check the Uvicorn process and logs."
    exit 1
}

Write-Host "[LumaScout NextLevel] Fetching truth payload..."
try {
    $truth = Invoke-RestMethod -Uri "http://127.0.0.1:8000/truth" -Method Get -TimeoutSec 10
    $truth | ConvertTo-Json -Depth 5 | Out-File -FilePath "$ROOT\reports\truth_dashboard_snapshot.json" -Encoding utf8
    Write-Host "[LumaScout NextLevel] Truth snapshot saved to reports\truth_dashboard_snapshot.json"
} catch {
    Write-Warning "Could not fetch truth endpoint. The UI may still work, but truth metrics are unavailable."
}

Write-Host "[LumaScout NextLevel] Opening UI..."
Start-Process "http://127.0.0.1:8000/ui"

Write-Host "[LumaScout NextLevel] Dashboard API process started with PID $($apiProcess.Id)."
Write-Host "Use CTRL+C in your terminal or stop the process manually if needed."
