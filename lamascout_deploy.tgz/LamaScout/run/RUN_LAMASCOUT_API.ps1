$ErrorActionPreference = "Stop"

$ROOT = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location "$ROOT\.."
$PY = "c:\LumaTrader\INSTITUTIONAL_STACK_V2\.venv\Scripts\python.exe"
& $PY -m uvicorn src.dashboard_api:app --host 0.0.0.0 --port 8000 --reload
