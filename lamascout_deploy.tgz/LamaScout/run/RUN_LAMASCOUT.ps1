$ErrorActionPreference = "Stop"

$ROOT = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location "$ROOT\.."
$PY = "c:\LumaTrader\INSTITUTIONAL_STACK_V2\.venv\Scripts\python.exe"
& $PY -m src.artist_scout_engine
