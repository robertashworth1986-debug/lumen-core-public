Maaven — EC Strength Studio
Our strength is making everyone else stronger.

WHAT YOU RECEIVED
A free LumenCore contribution for TakeOff Fall 2026. The public profile and
three workflow questions are independent research, open to your correction.
This is not an EC endorsement or an official site operated by Maaven.

START ON WINDOWS
Install Python 3.11 or newer from https://www.python.org/downloads/ if needed.
Open PowerShell in this extracted folder (right click > Open in Terminal),
then copy this command:

    python .\luma_runtime.py --member maaven

Open the address printed in the terminal:
    http://127.0.0.1:8766/cohort/?member=maaven

On macOS or Linux use: python3 ./luma_runtime.py --member maaven
No pip packages are required. Keep the terminal open; Ctrl+C stops the app.
If port 8766 is in use, add --port 8767 and use the printed address.

USE YOUR OWN AI KEY (OPTIONAL)
The workboard, measurement sheets, grant drafts, scout and paper tools work
without an AI key. The assistant uses your process OPENAI_API_KEY if set.
Your provider bills your own API usage. No key or paid subscription is included.
The key is never served to your browser or saved by this app.
For a temporary PowerShell session, enter your own key through a hidden prompt:

    $LumaSecret = Read-Host 'Your OpenAI API key' -AsSecureString
    $LumaPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($LumaSecret)
    try {
        $env:OPENAI_API_KEY = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($LumaPointer)
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($LumaPointer)
    }
    python .\luma_runtime.py --member maaven
    Remove-Item Env:OPENAI_API_KEY -ErrorAction SilentlyContinue

The default model is gpt-6-astra. Set LUMA_OPENAI_MODEL in the same terminal
only if your account requires another supported Responses model. AI is limited
to four requests per hour and 1,800 output tokens per request. A failed or
timed-out request may still incur provider usage; the app does not retry it.

WHAT THE TOOLS DO
- Workboard: briefs, acceptance criteria, owner review, dates and file hashes.
- Measure & improve: record observations and compare full-batch energy for
  equivalent accepted output. Failed work, rework and overhead remain included.
- Grant Factory: turn your supplied facts into Markdown drafts. Unknowns remain
  marked. No applicant attributes, eligibility, signatures or awards are invented.
- LumaScout: retrieve public Grants.gov listings; rank keywords, not eligibility.
- Paper Lab: simulate a 5/20 moving-average rule on fabricated or imported daily
  CSV prices. The optional local paper bot reads public BTC-USD quotes hourly,
  starts with 10,000 fictional USD, uses a 25% cash allocation, modeled 10 bps
  fees and 5 bps slippage, and reconciles its own paper ledger. No broker orders.
- LumaCare: practice nonclinical handoffs with fictional/non-sensitive IDs only.
- Assistant: sends your explicit prompt and public company context to OpenAI.
  It cannot access your workboard, customer files, clinical systems or accounts.

SCHEDULED WORK
The assistant, scout and paper screens show local task controls. You can enable
hourly public grant checks or the paper bot. The first scheduled run is one hour
after enabling. Tasks run only while this Python process stays open. Each run
records a success or failure, source receipts where applicable and a local
integrity-chain entry. Failed tasks do not become completed results.

YOUR DATA AND BACKUPS
The public page keeps entries in this browser. This local runtime also saves a
member-specific backup in .luma_data/maaven/workspace.sqlite3. Its journal files
are in the same folder. Use Export workspace to move data between computers;
Your free package > Import a backup loads the matching member's backup.
If this browser and the local backup contain different records, automatic
backup pauses. Choose Review saved versions to download either version and
select which records to keep. Two simultaneous sessions cannot silently
overwrite each other's local backup. Closing the notice leaves backup paused.
Keep the entire .luma_data folder private. It is ordinary local storage, not an
encrypted clinical database. Do not enter patient identifiers, diagnoses, secrets,
bank details or sensitive customer records. Revision files never leave the
browser; only their selected name and SHA-256 are stored.

The server binds only to 127.0.0.1 and rejects cross-origin API requests. It has
no remote accounts, email dispatch, grant submission, live-trade or equipment
control route. Team access and regulated data require a separate owner-approved
deployment and review. Government certification and HIPAA compliance are not
established by this package. Trading results are modeled, not profit evidence.

SOURCE AND REVIEW
Your three specific workflow hypotheses and source URLs: member-research.json
Package contents and hashes: package-manifest.json
Repository: https://github.com/robertashworth1986-debug/lumen-core-public
Public gift: https://lumen-core.ai/cohort/?member=maaven
Public strength profile: https://lumen-core.ai/cohort/members/maaven.html
Grants.gov: https://www.grants.gov/search-grants
OpenAI Responses: https://developers.openai.com/api/docs/guides/text
Coinbase public candles: https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-candles

Software: MIT (LICENSE.txt). Third-party notices: THIRD_PARTY_NOTICES.txt.
Public descriptions do not transfer another business's name, brand or materials.
