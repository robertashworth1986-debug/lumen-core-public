param(
    [switch]$Detach,
    [int]$Port = 7700,
    [int]$InfraRefreshSeconds = 30
)

$ErrorActionPreference = "Stop"

$ROOT = "C:\LumaTrader\INSTITUTIONAL_STACK_V2"
$CODE = Join-Path $ROOT "code"
$PY = Join-Path $CODE ".venv\Scripts\python.exe"
if (-not (Test-Path $PY)) {
    $PY = "python"
}

$SectorServer = Join-Path $CODE "execution\sector_opp_gain_server.py"
$CrossSectorRun = Join-Path $CODE "execution\run_cross_sector_intel.py"
$InfraDash = Join-Path $CODE "execution\build_infra_audit_dashboard.py"

if (-not (Test-Path $SectorServer)) { throw "Missing: $SectorServer" }
if (-not (Test-Path $CrossSectorRun)) { throw "Missing: $CrossSectorRun" }
if (-not (Test-Path $InfraDash)) { throw "Missing: $InfraDash" }

Write-Host "Cross-sector intelligence stack launcher" -ForegroundColor Cyan
Write-Host "Python: $PY"
Write-Host "Sector URL: http://127.0.0.1:$Port"

# Refresh cross-sector outputs once before serving.
& $PY $CrossSectorRun
& $PY $InfraDash

if ($Detach) {
    Start-Process -FilePath $PY -ArgumentList @("-m", "uvicorn", "execution.sector_opp_gain_server:app", "--host", "127.0.0.1", "--port", "$Port") -WorkingDirectory $CODE | Out-Null
    Start-Process -FilePath $PY -ArgumentList @($InfraDash, "--loop", "--interval", "$InfraRefreshSeconds") -WorkingDirectory $CODE | Out-Null
    Write-Host "Detached mode started: sector API + infra dashboard loop." -ForegroundColor Green
    exit 0
}

Write-Host "Starting sector opportunity API in foreground (Ctrl+C to stop)..." -ForegroundColor Yellow
& $PY -m uvicorn execution.sector_opp_gain_server:app --host 127.0.0.1 --port $Port
