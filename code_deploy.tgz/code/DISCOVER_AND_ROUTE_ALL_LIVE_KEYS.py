import os, re, json
from pathlib import Path
from datetime import datetime, timezone

try:
    import yaml  # type: ignore
except Exception:
    yaml = None

try:
    from out.canonical_extended_universe import CANONICAL_UNIVERSE
except Exception:
    try:
        from canonical_extended_universe import CANONICAL_UNIVERSE
    except Exception:
        CANONICAL_UNIVERSE = [
            "BTCUSD", "ETHUSD", "SOLUSD", "SPY", "QQQ", "XAUUSD"
        ]

ROOT = Path(r"C:\LumaTrader\INSTITUTIONAL_STACK_V2")
CONF = ROOT / "config"
OUT  = ROOT / "out"

for p in [ROOT, CONF, OUT]:
    p.mkdir(parents=True, exist_ok=True)

def now_utc():
    return datetime.now(timezone.utc).isoformat()

def load_json(path, default):
    p = Path(path)
    if not p.exists():
        return default
    for enc in ("utf-8","utf-8-sig","latin-1"):
        try:
            return json.loads(p.read_text(encoding=enc))
        except Exception:
            pass
    return default

def write_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2), encoding="utf-8")

CANON = {
    "FINNHUB_API_KEY": ["FINNHUB_API_KEY","FINNHUB_KEY"],
    "WEBHOOK_SHARED_SECRET": ["WEBHOOK_SHARED_SECRET","WEBHOOK_SECRET","FINNHUB_WEBHOOK_SECRET"],
    "ALPACA_API_KEY": ["ALPACA_API_KEY","APCA_API_KEY_ID","ALPACA_KEY"],
    "ALPACA_API_SECRET": ["ALPACA_API_SECRET","APCA_API_SECRET_KEY","ALPACA_SECRET"],
    "MASSIVE_API_KEY": ["MASSIVE_API_KEY","POLYGON_API_KEY","MASSIVE_KEY"],
    "ALPHAVANTAGE_API_KEY": ["ALPHAVANTAGE_API_KEY","ALPHA_VANTAGE_API_KEY","ALPHA_VANTAGE_KEY"],
    "TWELVE_DATA_API_KEY": ["TWELVE_DATA_API_KEY","TWELVEDATA_API_KEY","TWELVE_DATA_KEY"],
    "EPA_AQS_KEY": ["EPA_AQS_KEY","AQS_API_KEY","EPA_API_KEY","AQS_KEY"],
    "EPA_AQS_EMAIL": ["EPA_AQS_EMAIL","AQS_EMAIL","EPA_EMAIL"],
    "FRED_API_KEY": ["FRED_API_KEY","FRED_KEY"],
    "EIA_API_KEY": ["EIA_API_KEY","EIA_KEY"],
    "BLS_API_KEY": ["BLS_API_KEY","BLS_KEY"],
    "NASA_API_KEY": ["NASA_API_KEY","NASA_KEY"],
    "NOAA_API_TOKEN": ["NOAA_API_TOKEN","NCDC_API_KEY","NCEI_API_KEY","NOAA_TOKEN","NOAA_KEY"],
    "NREL_API_KEY": ["NREL_API_KEY","NREL_KEY"],
    "USGS_WATER_API_KEY": ["USGS_WATER_API_KEY","USGS_API_KEY","USGS_KEY"],
    "CENSUS_API_KEY": ["CENSUS_API_KEY","CENSUS_KEY"],
    "BEA_API_KEY": ["BEA_API_KEY","BEA_USER_ID","BEA_KEY"],
    "KRAKEN_API_KEY": ["KRAKEN_API_KEY","KRAKEN_KEY"],
    "KRAKEN_API_SECRET": ["KRAKEN_API_SECRET","KRAKEN_SECRET"],
    "IMPLIED_API_KEY": ["IMPLIED_API_KEY","IMPLIED_KEY","OPTIONS_API_KEY","IVOLATILITY_API_KEY","CBOE_API_KEY","VOLATILITY_API_KEY"]
}

SOURCE_MAP = {
    "finnhub":       ("FINNHUB_API_KEY", "market_data"),
    "webhook":       ("WEBHOOK_SHARED_SECRET", "internal"),
    "alpaca":        ("ALPACA_API_KEY", "broker"),
    "alpaca_secret": ("ALPACA_API_SECRET", "broker"),
    "massive":       ("MASSIVE_API_KEY", "market_data"),
    "alphavantage":  ("ALPHAVANTAGE_API_KEY", "market_data"),
    "twelve_data":   ("TWELVE_DATA_API_KEY", "market_data"),
    "epa_aqs_key":   ("EPA_AQS_KEY", "air_quality"),
    "epa_aqs_email": ("EPA_AQS_EMAIL", "air_quality"),
    "fred":          ("FRED_API_KEY", "rates"),
    "eia":           ("EIA_API_KEY", "energy"),
    "bls":           ("BLS_API_KEY", "labor"),
    "nasa":          ("NASA_API_KEY", "space"),
    "noaa_ncei":     ("NOAA_API_TOKEN", "weather"),
    "nrel":          ("NREL_API_KEY", "energy_lab"),
    "usgs_water":    ("USGS_WATER_API_KEY", "water"),
    "census":        ("CENSUS_API_KEY", "demographic"),
    "bea":           ("BEA_API_KEY", "macro"),
    "kraken":        ("KRAKEN_API_KEY", "crypto_exec"),
    "kraken_secret": ("KRAKEN_API_SECRET", "crypto_exec"),
    "implied":       ("IMPLIED_API_KEY", "options")
}

LAMASCOUT_API_REGISTRY = ROOT / "LamaScout" / "config" / "api_registry.yaml"
LAMASCOUT_SOURCE_MAP = {
    "youtube": ("YOUTUBE_API_KEY", "digital_scout"),
    "spotify": ("SPOTIFY_CLIENT_ID", "digital_scout"),
    "spotify_secret": ("SPOTIFY_CLIENT_SECRET", "digital_scout"),
    "twitter_x": ("TWITTER_BEARER_TOKEN", "digital_scout"),
    "ticketmaster": ("TICKETMASTER_API_KEY", "sports_odds"),
    "news_api": ("NEWSAPI_KEY", "digital_scout"),
}

CANON.update(
    {
        "YOUTUBE_API_KEY": ["YOUTUBE_API_KEY", "GOOGLE_API_KEY", "YT_API_KEY"],
        "SPOTIFY_CLIENT_ID": ["SPOTIFY_CLIENT_ID", "SPOTIFY_API_CLIENT_ID"],
        "SPOTIFY_CLIENT_SECRET": ["SPOTIFY_CLIENT_SECRET", "SPOTIFY_API_CLIENT_SECRET"],
        "TWITTER_BEARER_TOKEN": ["TWITTER_BEARER_TOKEN", "X_BEARER_TOKEN"],
        "TICKETMASTER_API_KEY": ["TICKETMASTER_API_KEY"],
        "NEWSAPI_KEY": ["NEWSAPI_KEY", "NEWS_API_KEY"],
        "THEODDS_API_KEY": ["THEODDS_API_KEY", "ODDS_API_KEY", "SPORTS_ODDS_API_KEY"],
    }
)

SOURCE_MAP.update(
    {
        "theodds": ("THEODDS_API_KEY", "sports_odds"),
        **LAMASCOUT_SOURCE_MAP,
    }
)

SEARCH_ROOTS = [
    Path(r"C:\LumaTrader"),
    Path(r"C:\Users\Novac"),
    Path(r"C:\Users\Novac\iCloudDrive"),
    Path.home()
]

TEXT_EXTS = {".env",".txt",".json",".jsonl",".py",".ps1",".cmd",".bat",".ini",".cfg",".yaml",".yml",".toml",".md"}

SKIP_BITS = [
    r"\.git\\", r"\node_modules\\", r"\.venv\\", r"\venv\\", r"\__pycache__\\",
    r"\AppData\Local\Packages\\", r"\site-packages\\", r"\Google\Chrome\\",
    r"\Microsoft\Edge\\", r"\Mozilla\\", r"\Temp\\"
]

assign_patterns = [
    re.compile(r'^\s*(?:export\s+|set\s+)?([A-Za-z0-9_]+)\s*[:=]\s*["\']?([^"\';#\r\n]+)["\']?\s*$'),
    re.compile(r'^\s*\$env:([A-Za-z0-9_]+)\s*=\s*["\']?([^"\';#\r\n]+)["\']?\s*$')
]

def looks_real(v):
    if v is None:
        return False
    v = str(v).strip()
    if len(v) < 8:
        return False
    bad = ["your_", "replace", "example", "changeme", "null", "none"]
    return not any(x in v.lower() for x in bad)

found = {}
evidence = []

def maybe_store(canonical, matched_name, value, path, line_no):
    if canonical not in found and looks_real(value):
        found[canonical] = str(value).strip()
        evidence.append({
            "canonical": canonical,
            "matched_name": matched_name,
            "path": str(path),
            "line": line_no
        })


def merge_lamascout_keys():
    if yaml is None or not LAMASCOUT_API_REGISTRY.exists():
        return
    try:
        payload = yaml.safe_load(LAMASCOUT_API_REGISTRY.read_text(encoding="utf-8")) or {}
    except Exception:
        return
    for row in payload.get("sources", []) if isinstance(payload, dict) else []:
        if not isinstance(row, dict):
            continue
        src = str(row.get("name", "")).strip().lower()
        auth = row.get("auth", {}) if isinstance(row.get("auth", {}), dict) else {}
        if src == "youtube":
            val = str(auth.get("api_key", "")).strip()
            if looks_real(val):
                maybe_store("YOUTUBE_API_KEY", "api_registry.youtube.auth.api_key", val, LAMASCOUT_API_REGISTRY, 0)
        elif src == "spotify":
            cid = str(auth.get("client_id", "")).strip()
            csec = str(auth.get("client_secret", "")).strip()
            if looks_real(cid):
                maybe_store("SPOTIFY_CLIENT_ID", "api_registry.spotify.auth.client_id", cid, LAMASCOUT_API_REGISTRY, 0)
            if looks_real(csec):
                maybe_store("SPOTIFY_CLIENT_SECRET", "api_registry.spotify.auth.client_secret", csec, LAMASCOUT_API_REGISTRY, 0)
        elif src == "twitter_x":
            val = str(auth.get("bearer_token", "")).strip()
            if looks_real(val):
                maybe_store("TWITTER_BEARER_TOKEN", "api_registry.twitter_x.auth.bearer_token", val, LAMASCOUT_API_REGISTRY, 0)
        elif src == "ticketmaster":
            val = str(auth.get("api_key", "")).strip()
            if looks_real(val):
                maybe_store("TICKETMASTER_API_KEY", "api_registry.ticketmaster.auth.api_key", val, LAMASCOUT_API_REGISTRY, 0)
        elif src == "news_api":
            val = str(auth.get("api_key", "")).strip()
            if looks_real(val):
                maybe_store("NEWSAPI_KEY", "api_registry.news_api.auth.api_key", val, LAMASCOUT_API_REGISTRY, 0)

for canonical, aliases in CANON.items():
    for a in aliases:
        v = os.environ.get(a)
        if looks_real(v):
            maybe_store(canonical, a, v, "<process-env>", 0)
            break

for root in SEARCH_ROOTS:
    if not root.exists():
        continue
    for p in root.rglob("*"):
        try:
            sp = str(p)
            if not p.is_file():
                continue
            if p.suffix.lower() not in TEXT_EXTS:
                continue
            if any(bit.lower() in sp.lower() for bit in SKIP_BITS):
                continue
            txt = p.read_text(encoding="utf-8", errors="ignore")
            for i, line in enumerate(txt.splitlines(), start=1):
                for pat in assign_patterns:
                    m = pat.match(line)
                    if not m:
                        continue
                    k = m.group(1).strip()
                    v = m.group(2).strip()
                    for canonical, aliases in CANON.items():
                        if k in aliases and looks_real(v):
                            maybe_store(canonical, k, v, p, i)
        except Exception:
            pass

merge_lamascout_keys()

env_file = CONF / "luma_live_keys.env"
env_lines = [f"{k}={found[k]}" for k in sorted(found)]
env_file.write_text("\n".join(env_lines) + ("\n" if env_lines else ""), encoding="utf-8")

live_sources = load_json(CONF / "live_sources.json", {})
if not isinstance(live_sources, dict):
    live_sources = {}

registry_rows = []

for src, (env_name, sector) in SOURCE_MAP.items():
    enabled = env_name in found
    entry = live_sources.get(src, {})
    if not isinstance(entry, dict):
        entry = {}
    entry["enabled"] = enabled
    entry["api_key_env"] = env_name
    entry["sector"] = sector
    live_sources[src] = entry

    registry_rows.append({
        "source": src.upper(),
        "sector": sector,
        "status": "LIVE_KEY_PRESENT" if enabled else "MISSING",
        "rows": 1 if enabled else 0,
        "last_probe_utc": now_utc(),
        "env": env_name,
        "enabled": enabled,
        "basis": "KEY_PRESENT" if enabled else "MISSING",
        "value_basis": "ROUTED" if enabled else "MISSING"
    })

write_json(CONF / "live_sources.json", live_sources)

runtime_control = load_json(CONF / "runtime_control.json", {})
if not isinstance(runtime_control, dict):
    runtime_control = {}
runtime_control["mode"] = "paper"
runtime_control["allow_live_orders"] = False
runtime_control["kill_switch"] = False
runtime_control["symbol"] = "UNIVERSE"
runtime_control["paper_capital_usd"] = float(runtime_control.get("paper_capital_usd", 200.0))
runtime_control["max_notional_per_trade_usd"] = float(runtime_control.get("max_notional_per_trade_usd", 25.0))
runtime_control["max_daily_loss_usd"] = float(runtime_control.get("max_daily_loss_usd", 20.0))
runtime_control["max_open_positions"] = int(runtime_control.get("max_open_positions", 1))
runtime_control["loop_seconds"] = int(runtime_control.get("loop_seconds", 5))
write_json(CONF / "runtime_control.json", runtime_control)

paper_runtime = load_json(CONF / "paper_trader_runtime.json", {})
if not isinstance(paper_runtime, dict):
    paper_runtime = {}

symbols = list(CANONICAL_UNIVERSE)

paper_runtime["paper_enabled"] = True
paper_runtime["starting_capital_usd"] = float(paper_runtime.get("starting_capital_usd", 100000.0))
paper_runtime["loop_seconds"] = int(paper_runtime.get("loop_seconds", 300))
paper_runtime["symbols"] = symbols
write_json(CONF / "paper_trader_runtime.json", paper_runtime)

write_json(CONF / "live_source_registry.json", {
    "generated_utc": now_utc(),
    "paper_live_linked": True,
    "rows": registry_rows,
    "sources": registry_rows,
})

write_json(OUT / "source_truth_table.json", {
    "generated_utc": now_utc(),
    "rows": registry_rows,
    "sources": registry_rows,
})

enabled_count = sum(1 for r in registry_rows if bool(r.get("enabled")))
measured_count = sum(1 for r in registry_rows if str(r.get("status", "")).upper() == "LIVE_KEY_PRESENT")
paper_runtime["enabled_sources_count"] = enabled_count
paper_runtime["measured_sources_count"] = measured_count
paper_runtime["selection_source"] = "engine_logic"
paper_runtime["symbol_mode"] = "ADAPTIVE_UNIVERSE"
paper_runtime["universe_mode"] = True
paper_runtime["runtime_symbol"] = "UNIVERSE"
write_json(CONF / "paper_trader_runtime.json", paper_runtime)

write_json(OUT / "live_key_routing_summary.json", {
    "generated_utc": now_utc(),
    "found_count": len(found),
    "found_keys": sorted(found.keys()),
    "evidence_count": len(evidence),
    "evidence": evidence,
    "env_file": str(env_file),
    "paper_symbols_count": len(symbols),
    "paper_symbols": symbols,
    "runtime_mode": runtime_control["mode"],
    "runtime_symbol": runtime_control["symbol"],
    "registry_json": str(CONF / "live_source_registry.json"),
    "truth_json": str(OUT / "source_truth_table.json")
})

print("")
print("DISCOVERY + ROUTING COMPLETE")
print("FOUND KEYS:", len(found))
print("ENV FILE:", env_file)
print("RUNTIME MODE:", runtime_control["mode"])
print("RUNTIME SYMBOL:", runtime_control["symbol"])
print("PAPER SYMBOLS:", len(symbols))
print("ENABLED SOURCES:", enabled_count)
print("MEASURED SOURCES:", measured_count)
print("")
print("FOUND KEY NAMES:")
for k in sorted(found.keys()):
    print(" -", k)
print("")
print("OUTPUT FILES:")
print(" -", CONF / "luma_live_keys.env")
print(" -", CONF / "live_sources.json")
print(" -", CONF / "live_source_registry.json")
print(" -", OUT / "source_truth_table.json")
print(" -", OUT / "live_key_routing_summary.json")