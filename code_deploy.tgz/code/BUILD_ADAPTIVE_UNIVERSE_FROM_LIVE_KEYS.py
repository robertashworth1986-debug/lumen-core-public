import os, re, io, csv, json, math, time, sys
from pathlib import Path
from datetime import datetime, timezone

import requests

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from CUTOVER_TO_ADAPTIVE_ENGINE_LOGIC import load_json, save_json, now_utc
from FORCE_REBUILD_SEED_VALIDATION import norm
from FULL_TRUTH_ORCHESTRATOR import RUNTIME_CONTROL_PATH
from REBUILD_SINGLE_TRUTH_AND_REVALIDATE import DATA_ROOTS
from dashboard_unified_refresh import PAPER_DASH_PATH, REG_PATH


# --- Path Constants ---
ROOT = Path(r"C:/LumaTrader/INSTITUTIONAL_STACK_V2")
CONF = ROOT / "config"
OUT = ROOT / "out"

RUNTIME_PATH = CONF / "runtime_control.json"
PAPER_PATH = CONF / "paper_trader_runtime.json"
ADAPTIVE_JSON = OUT / "adaptive_universe.json"
ADAPTIVE_CSV = OUT / "adaptive_universe.csv"
SUMMARY_JSON = OUT / "adaptive_universe_summary.json"

# --- Environment Merge ---
def merged_env():
    env = dict(os.environ)
    try:
        from dotenv import dotenv_values
        env.update(dotenv_values())
    except Exception:
        pass
    return env



# --- Utility: Infer sector from path or text ---
def infer_sector(t):
    if any(k in t for k in ["eia","pjm","miso","nyiso","ercot","isone","energy"]):
        return "energy"
    if any(k in t for k in ["fred","rates","dgs","yield","treasury"]):
        return "rates"
    if any(k in t for k in ["bls","labor","unrate","employment"]):
        return "labor"
    if any(k in t for k in ["bea","macro","gdp","income"]):
        return "macro"
    if any(k in t for k in ["census","demographic","population"]):
        return "demographic"
    if any(k in t for k in ["noaa","weather","ncei","climate"]):
        return "weather"
    if any(k in t for k in ["nrel","solar","wind","lab"]):
        return "energy_lab"
    if any(k in t for k in ["usgs","water","streamflow","hydrology"]):
        return "water"
    if any(k in t for k in ["nasa","space"]):
        return "space"
    if any(k in t for k in ["aqs","epa","air quality"]):
        return "air_quality"
    return "unknown"


def load_registry():
    reg = load_json(get_registry_path(), {})
    rows = reg.get("rows", []) if isinstance(reg, dict) else []
    out = {}
    for r in rows:
        if isinstance(r, dict):
            out[str(r.get("source","")).upper()] = r
    return out

def get_registry_path():
    return REG_PATH

def http_get_json(url, headers=None, params=None, timeout=20):
    if requests is None:
        return None
    try:
        r = requests.get(url, headers=headers or {}, params=params or {}, timeout=timeout)
        if r.status_code >= 200 and r.status_code < 300:
            return r.json()
    except Exception:
        return None
    return None

def build_from_alpaca(env):
    key = env.get("ALPACA_API_KEY")
    sec = env.get("ALPACA_API_SECRET")
    if not key or not sec:
        return []

    headers = {
        "APCA-API-KEY-ID": key,
        "APCA-API-SECRET-KEY": sec,
    }

    assets = http_get_json(
        "https://paper-api.alpaca.markets/v2/assets",
        headers=headers,
        params={"status":"active","asset_class":"us_equity"},
        timeout=30
    )
    if not isinstance(assets, list):
        return []

    rows = []
    for a in assets:
        try:
            if not a.get("tradable"):
                continue
            sym = str(a.get("symbol","")).upper().strip()
            if not sym:
                continue
            exch = str(a.get("exchange","")).upper()
            score = 100.0
            if exch in ("NASDAQ","NYSE","ARCA","AMEX","BATS"):
                score += 20.0
            if a.get("fractionable"):
                score += 5.0
            if a.get("shortable"):
                score += 3.0
            rows.append({
                "symbol": sym,
                "asset_class": "equity",
                "sector": "broker",
                "source": "ALPACA",
                "evidence": "LIVE_ENUMERATION",
                "score": round(score, 2)
            })
        except Exception:
            pass
    return rows

def build_from_kraken(env):
    payload = http_get_json("https://api.kraken.com/0/public/AssetPairs", timeout=30)
    if not isinstance(payload, dict):
        return []
    result = payload.get("result", {})
    if not isinstance(result, dict):
        return []

    rows = []
    for k, v in result.items():
        try:
            ws = str(v.get("wsname","") or "")
            alt = str(v.get("altname","") or "")
            base = str(v.get("base","") or "")
            quote = str(v.get("quote","") or "")
            if ws and "/" in ws:
                sym = ws.replace("/", "")
            elif alt:
                sym = alt
            else:
                continue

            sym_u = sym.upper().replace(".","").replace("-","")
            quote_text = f"{quote} {ws} {alt}".upper()

            if any(q in quote_text for q in ["USD","USDT","ZUSD"]):
                score = 100.0
            else:
                score = 70.0

            if any(b in quote_text for b in ["XBT","BTC","ETH","SOL","XRP","ADA","AVAX","DOT","LINK","DOGE"]):
                score += 20.0

            rows.append({
                "symbol": sym_u,
                "asset_class": "crypto",
                "sector": "crypto_exec",
                "source": "KRAKEN",
                "evidence": "LIVE_ENUMERATION",
                "score": round(score, 2)
            })
        except Exception:
            pass
    return rows

def scan_dataset_symbols():
    hits = []
    ticker_cols = {"symbol","ticker","pair","instrument","underlying","asset","contract"}
    known_tickers = set()

    for root in DATA_ROOTS:
        if not root.exists():
            continue
        for p in root.rglob("*.csv"):
            try:
                with p.open("r", encoding="utf-8-sig", errors="ignore", newline="") as f:
                    sample = f.read(65536)
                if not sample.strip():
                    continue
                reader = csv.DictReader(io.StringIO(sample))
                cols = [str(c).strip() for c in (reader.fieldnames or []) if c]
                lowcols = {c.lower() for c in cols}

                found_col = None
                for c in cols:
                    if c.lower() in ticker_cols:
                        found_col = c
                        break

                if found_col:
                    with p.open("r", encoding="utf-8-sig", errors="ignore", newline="") as f:
                        dr = csv.DictReader(f)
                        count = 0
                        for row in dr:
                            raw = str(row.get(found_col,"")).strip().upper()
                            raw = raw.replace("/","").replace("-","").replace(".","")
                            if 2 <= len(raw) <= 15 and re.fullmatch(r"[A-Z0-9]+", raw):
                                known_tickers.add((raw, str(p)))
                            count += 1
                            if count >= 1500:
                                break
                else:
                    name = p.name.upper()
                    m = re.findall(r"\b[A-Z]{2,5}(?:USD|USDT)?\b", name.replace("-"," ").replace("_"," "))
                    for sym in m:
                        if 2 <= len(sym) <= 12:
                            known_tickers.add((sym, str(p)))
            except Exception:
                pass

    for sym, srcpath in sorted(known_tickers):
        sector = infer_sector(srcpath)
        asset_class = "crypto" if any(sym.endswith(q) for q in ["USD","USDT"]) or sym in {"XBTUSD","BTCUSD","ETHUSD","SOLUSD","XRPUSD","ADAUSD","DOGEUSD"} else "unknown"
        hits.append({
            "symbol": sym,
            "asset_class": asset_class,
            "sector": sector,
            "source": "DATASET_SCAN",
            "evidence": "MEASURED_DATASET_SYMBOL",
            "score": 40.0
        })
    return hits

def load_local_registry_symbols():
    rows = []
    try:
        from symbol_registry_auto import SYMBOL_REGISTRY
    except Exception:
        return rows

    for sym, info in SYMBOL_REGISTRY.items():
        try:
            symbol = str(sym or "").upper().strip()
            if not symbol:
                continue
            exchange = str(info.get("exchange", "")).lower()
            pair = str(info.get("pair", "")).upper().strip()
            asset_class = "unknown"
            sector = "unknown"
            score = 10.0

            if exchange in ("alpaca", "broker", "equity") or symbol.isalpha() and len(symbol) <= 5:
                asset_class = "equity"
                sector = "broker"
                score = 20.0
            elif exchange in ("kraken", "binance", "crypto", "crypto_exec") or any(x in pair for x in ["BTC", "ETH", "SOL", "XRP", "ADA", "AVAX", "DOT", "LINK", "MATIC", "DOGE"]):
                asset_class = "crypto"
                sector = "crypto_exec"
                score = 20.0
            elif exchange in ("fx", "forex") or "/" in symbol and symbol.endswith("USD"):
                asset_class = "crypto"
                sector = "crypto_exec"
                score = 15.0

            rows.append({
                "symbol": symbol,
                "asset_class": asset_class,
                "sector": sector,
                "source": "LOCAL_REGISTRY",
                "evidence": "LOCAL_REGISTRY",
                "score": score
            })
        except Exception:
            continue
    return rows


def merge_rows(*groups):
    merged = {}
    for group in groups:
        for r in group:
            sym = norm(r.get("symbol"))
            if not sym:
                continue
            if sym not in merged:
                merged[sym] = dict(r)
                merged[sym]["symbol"] = sym
                merged[sym]["sources"] = [r.get("source")]
                merged[sym]["evidence_set"] = [r.get("evidence")]
            else:
                merged[sym]["score"] = round(float(merged[sym].get("score",0.0)) + float(r.get("score",0.0)), 2)
                src = r.get("source")
                ev  = r.get("evidence")
                if src and src not in merged[sym]["sources"]:
                    merged[sym]["sources"].append(src)
                if ev and ev not in merged[sym]["evidence_set"]:
                    merged[sym]["evidence_set"].append(ev)
                if merged[sym].get("asset_class") in ("unknown","") and r.get("asset_class") not in ("unknown",""):
                    merged[sym]["asset_class"] = r.get("asset_class")
                if merged[sym].get("sector") in ("unknown","") and r.get("sector") not in ("unknown",""):
                    merged[sym]["sector"] = r.get("sector")
    return list(merged.values())

def sort_and_trim(rows):
    def keyfn(r):
        return (
            float(r.get("score",0.0)),
            1 if r.get("asset_class") == "equity" else 0,
            1 if r.get("asset_class") == "crypto" else 0,
            len(r.get("sources",[])),
            r.get("symbol","")
        )
    rows = sorted(rows, key=keyfn, reverse=True)

    equities = [r for r in rows if r.get("asset_class") == "equity"]
    cryptos  = [r for r in rows if r.get("asset_class") == "crypto"]
    other    = [r for r in rows if r.get("asset_class") not in ("equity","crypto")]

    # Remove slice limits: include all discovered symbols
    final = equities + cryptos + other
    return final

def patch_runtime_files(symbols):

    runtime = load_json(RUNTIME_PATH, {})
    paper   = load_json(PAPER_PATH, {})

    runtime["symbol"] = "UNIVERSE"
    runtime["mode"] = runtime.get("mode", "paper")
    runtime["allow_live_orders"] = False

    paper["paper_enabled"] = True
    paper["symbols"] = symbols
    paper["symbol_count"] = len(symbols)
    if "loop_seconds" not in paper:
        paper["loop_seconds"] = 5

    save_json(RUNTIME_PATH, runtime)
    save_json(PAPER_PATH, paper)

def main():
    env = merged_env()
    registry = load_registry()

    alpaca_rows = build_from_alpaca(env)
    kraken_rows = build_from_kraken(env)
    dataset_rows = scan_dataset_symbols()
    registry_rows = load_local_registry_symbols()

    merged = merge_rows(alpaca_rows, kraken_rows, dataset_rows, registry_rows)

    enabled_sources = [k for k,v in registry.items() if isinstance(v, dict) and v.get("enabled")]

    # Boost rows whose source is actually enabled in registry
    for r in merged:
        bonus = 0.0
        for s in r.get("sources", []):
            if str(s).upper() in enabled_sources:
                bonus += 25.0
        r["score"] = round(float(r.get("score",0.0)) + bonus, 2)

    final_rows = sort_and_trim(merged)
    final_symbols = [r["symbol"] for r in final_rows]

    patch_runtime_files(final_symbols)

    adaptive = {
        "generated_utc": now_utc(),
        "engine_mode": "adaptive_live_key_driven",
        "hardcoded_static_lists": False,
        "discovery": {
            "alpaca_count": len(alpaca_rows),
            "kraken_count": len(kraken_rows),
            "dataset_symbol_count": len(dataset_rows),
            "merged_count": len(merged),
            "final_count": len(final_rows)
        },
        "rows": final_rows
    }

    summary = {
        "generated_utc": now_utc(),
        "adaptive_universe_json": str(ADAPTIVE_JSON),
        "adaptive_universe_csv": str(ADAPTIVE_CSV),
        "paper_runtime_json": str(PAPER_PATH),
        "runtime_control_json": str(RUNTIME_PATH),
        "hardcoded_static_lists": False,
        "alpaca_live_detected": bool(env.get("ALPACA_API_KEY") and env.get("ALPACA_API_SECRET")),
        "kraken_live_detected": bool(env.get("KRAKEN_API_KEY") and env.get("KRAKEN_API_SECRET")),
        "local_registry_detected": len(registry_rows) > 0,
        "registry_symbol_count": len(registry_rows),
        "enabled_registry_sources": len(enabled_sources),
        "final_symbol_count": len(final_rows),
        "top10": [r["symbol"] for r in final_rows[:10]]
    }

    save_json(ADAPTIVE_JSON, adaptive)
    save_json(SUMMARY_JSON, summary)

    with ADAPTIVE_CSV.open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["symbol","asset_class","sector","score","sources","evidence"])
        for r in final_rows:
            w.writerow([
                r.get("symbol",""),
                r.get("asset_class",""),
                r.get("sector",""),
                r.get("score",""),
                "|".join(r.get("sources",[])),
                "|".join(r.get("evidence_set",[])),
            ])

    print("ADAPTIVE UNIVERSE BUILT")
    print("ALPACA ENUM:", len(alpaca_rows))
    print("KRAKEN ENUM:", len(kraken_rows))
    print("DATASET SYMBOLS:", len(dataset_rows))
    print("FINAL SYMBOL COUNT:", len(final_rows))
    print("TOP 10:", ", ".join(summary["top10"]))

if __name__ == "__main__":
    main()