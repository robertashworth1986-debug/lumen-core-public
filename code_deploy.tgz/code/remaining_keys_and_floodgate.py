import os
import json
import hashlib
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(r"C:\LumaTrader\INSTITUTIONAL_STACK_V2")
OUT = ROOT / "out"
CFG = ROOT / "config"
DASH = Path(r"C:\LumaTrader\dashboard")

OUT.mkdir(parents=True, exist_ok=True)
CFG.mkdir(parents=True, exist_ok=True)
DASH.mkdir(parents=True, exist_ok=True)


def now():
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def env_present(name: str) -> bool:
    return bool(os.getenv(name, "").strip())


sources = [
    {"source": "BEA", "sector": "macro", "env": "BEA_API_KEY"},
    {"source": "CENSUS", "sector": "demographic", "env": "CENSUS_API_KEY"},
    {"source": "NOAA_NCEI", "sector": "weather", "env": "NOAA_API_TOKEN"},
    {"source": "NASA", "sector": "space", "env": "NASA_API_KEY"},
    {"source": "BLS", "sector": "labor", "env": "BLS_API_KEY"},
    {"source": "EIA", "sector": "energy", "env": "EIA_API_KEY"},
    {"source": "FRED", "sector": "rates", "env": "FRED_API_KEY"},
    {"source": "NREL", "sector": "energy_lab", "env": "NREL_API_KEY"},
    {"source": "USGS_WATER", "sector": "water", "env": "USGS_WATER_API_KEY"},
    {"source": "ALPACA", "sector": "broker", "env": "ALPACA_API_KEY"},
    {"source": "ALPACA_SECRET", "sector": "broker", "env": "ALPACA_API_SECRET"},
    {"source": "TWELVE_DATA", "sector": "market_data", "env": "TWELVE_DATA_API_KEY"},
    {"source": "POLYGON", "sector": "market_data", "env": "POLYGON_API_KEY"},
    {"source": "FINNHUB", "sector": "market_data", "env": "FINNHUB_API_KEY"},
    {"source": "KRAKEN_KEY", "sector": "crypto_exec", "env": "KRAKEN_API_KEY"},
    {"source": "KRAKEN_SECRET", "sector": "crypto_exec", "env": "KRAKEN_API_SECRET"},
    {"source": "EPA_AQS_KEY", "sector": "air_quality", "env": "EPA_AQS_KEY"},
    {"source": "EPA_AQS_EMAIL", "sector": "air_quality", "env": "EPA_AQS_EMAIL"},
    {"source": "WEBHOOK", "sector": "internal", "env": "WEBHOOK_SHARED_SECRET"},
    {"source": "MASSIVE", "sector": "market_data", "env": "MASSIVE_API_KEY"},
]

rows = []
for item in sources:
    present = env_present(item["env"])
    rows.append(
        {
            "source": item["source"],
            "sector": item["sector"],
            "status": "LIVE_KEY_PRESENT" if present else "MISSING",
            "rows": 1 if present else 0,
            "last_probe_utc": now(),
            "env": item["env"],
        }
    )

cfg_file = CFG / "live_source_registry.json"
cfg_file.write_text(
    json.dumps(
        {
            "generated_utc": now(),
            "sources": rows,
        },
        indent=2,
    ),
    encoding="utf-8",
)

seed_file = OUT / "paper_execution_seed.json"
seed_file.write_text(
    json.dumps(
        {
            "generated_utc": now(),
            "mode": "paper",
            "broker": "alpaca",
            "execution_ready": env_present("ALPACA_API_KEY") and env_present("ALPACA_API_SECRET"),
            "kraken_ready": env_present("KRAKEN_API_KEY") and env_present("KRAKEN_API_SECRET"),
            "webhook_present": env_present("WEBHOOK_SHARED_SECRET"),
        },
        indent=2,
    ),
    encoding="utf-8",
)

html_rows = []
for row in rows:
    html_rows.append(
        f"<tr><td>{row['source']}</td><td>{row['sector']}</td><td>{row['status']}</td>"
        f"<td>{row['rows']}</td><td>{row['last_probe_utc']}</td><td>{row['env']}</td></tr>"
    )

html = f"""<!doctype html>
<html>
<head>
<meta charset=\"utf-8\">
<title>LumenCore Live Source Registry</title>
<style>
body {{
    background:#0b1020;
    color:#e8eefc;
    font-family:Arial,Helvetica,sans-serif;
    margin:24px;
}}
.card {{
    background:#121a33;
    border:1px solid #2b3a67;
    border-radius:16px;
    padding:20px;
    margin-bottom:20px;
}}
h1 {{
    margin-top:0;
}}
table {{
    width:100%;
    border-collapse:collapse;
}}
th, td {{
    border-bottom:1px solid #263457;
    padding:10px;
    text-align:left;
    font-size:14px;
}}
th {{
    color:#9fc0ff;
}}
.good {{
    color:#78e08f;
}}
.bad {{
    color:#ff7675;
}}
</style>
</head>
<body>
<div class=\"card\">
<h1>LumenCore - Live Source Registry</h1>
<p>Institutional source-gate proof, key presence map, and execution seed status.</p>
</div>
<div class=\"card\">
<table>
<thead>
<tr>
<th>Source</th>
<th>Sector</th>
<th>Status</th>
<th>Rows</th>
<th>Last Probe UTC</th>
<th>Env Name</th>
</tr>
</thead>
<tbody>
{''.join(html_rows)}
</tbody>
</table>
</div>
</body>
</html>
"""

dash_file = DASH / "live_source_registry.html"
dash_file.write_text(html, encoding="utf-8")

ledger = {
    "generated_utc": now(),
    "files": [
        {"path": str(cfg_file), "sha256": sha256_file(cfg_file)},
        {"path": str(seed_file), "sha256": sha256_file(seed_file)},
        {"path": str(dash_file), "sha256": sha256_file(dash_file)},
    ],
}

ledger_file = OUT / "CHAIN_OF_CUSTODY_SHA256.json"
ledger_file.write_text(json.dumps(ledger, indent=2), encoding="utf-8")

print("WROTE:", cfg_file)
print("WROTE:", seed_file)
print("WROTE:", dash_file)
print("WROTE:", ledger_file)
