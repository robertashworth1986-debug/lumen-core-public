import os, re, json
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(r"C:\LumaTrader\INSTITUTIONAL_STACK_V2")
CONF = ROOT / "config"
OUT  = ROOT / "out"
DASH = Path(r"C:\LumaTrader\dashboard")

for p in [ROOT, CONF, OUT, DASH]:
    p.mkdir(parents=True, exist_ok=True)

def now_utc():
    return datetime.now(timezone.utc).isoformat()

def load_json(path, default):
    try:
        if Path(path).exists():
            return json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        pass
    return default

def save_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2), encoding="utf-8")

def parse_env_text(txt):
    found = {}
    for line in txt.splitlines():
        s = line.strip()
        if not s or s.startswith("#") or "=" not in s:
            continue
        k, v = s.split("=", 1)
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k and v:
            found[k] = v
    return found

def harvest_env_files():
    roots = [
        Path.home(),
        Path(r"C:\LumaTrader"),
        ROOT,
        Path.home() / "Desktop",
        Path.home() / "Documents"
    ]
    names = [
        ".env", ".env.local", ".env.ultra", ".env.prod", ".env.production",
        "luma_live_keys.env", "live_keys.env", "keys.env"
    ]
    found = {}
    for base in roots:
        try:
            if not base.exists():
                continue
            for nm in names:
                p = base / nm
                if p.exists():
                    try:
                        found.update(parse_env_text(p.read_text(encoding="utf-8", errors="ignore")))
                    except Exception:
                        pass
            for p in base.rglob("*.env"):
                try:
                    found.update(parse_env_text(p.read_text(encoding="utf-8", errors="ignore")))
                except Exception:
                    pass
        except Exception:
            pass
    return found

# 1) pull from process/user/machine env first
env_all = dict(os.environ)

# 2) merge any .env content we can find
env_all.update(harvest_env_files())

# canonical key map
REGISTRY = {
    "ALPACA_API_KEY":        {"source":"ALPACA",      "sector":"broker"},
    "ALPACA_API_SECRET":     {"source":"ALPACA",      "sector":"broker"},
    "ALPHAVANTAGE_API_KEY":  {"source":"ALPHAVANTAGE","sector":"market_data"},
    "BEA_API_KEY":           {"source":"BEA",         "sector":"macro"},
    "BLS_API_KEY":           {"source":"BLS",         "sector":"labor"},
    "CENSUS_API_KEY":        {"source":"CENSUS",      "sector":"demographic"},
    "EIA_API_KEY":           {"source":"EIA",         "sector":"energy"},
    "EPA_AQS_EMAIL":         {"source":"EPA_AQS",     "sector":"air_quality"},
    "EPA_AQS_KEY":           {"source":"EPA_AQS",     "sector":"air_quality"},
    "FINNHUB_API_KEY":       {"source":"FINNHUB",     "sector":"market_data"},
    "FRED_API_KEY":          {"source":"FRED",        "sector":"rates"},
    "KRAKEN_API_KEY":        {"source":"KRAKEN",      "sector":"crypto_exec"},
    "KRAKEN_API_SECRET":     {"source":"KRAKEN",      "sector":"crypto_exec"},
    "MASSIVE_API_KEY":       {"source":"MASSIVE",     "sector":"market_data"},
    "NASA_API_KEY":          {"source":"NASA",        "sector":"space"},
    "NOAA_API_TOKEN":        {"source":"NOAA_NCEI",   "sector":"weather"},
    "NREL_API_KEY":          {"source":"NREL",        "sector":"energy_lab"},
    "TWELVE_DATA_API_KEY":   {"source":"TWELVE_DATA", "sector":"market_data"},
    "USGS_WATER_API_KEY":    {"source":"USGS_WATER",  "sector":"water"},
    "WEBHOOK_SHARED_SECRET": {"source":"WEBHOOK",     "sector":"internal"},
}

# aliases / repairs
ALIASES = {
    "ALPHA_VANTAGE_API_KEY": "ALPHAVANTAGE_API_KEY",
    "ALPACA_SECRET": "ALPACA_API_SECRET",
    "KRAKEN_SECRET": "KRAKEN_API_SECRET",
    "NOAA_NCEI_API_TOKEN": "NOAA_API_TOKEN",
    "USGS_API_KEY": "USGS_WATER_API_KEY",
    "TWELVE_API_KEY": "TWELVE_DATA_API_KEY",
    "AQS_TOKEN": "EPA_AQS_KEY",
    "AQS_KEY": "EPA_AQS_KEY",
    "EPA_AQS_TOKEN": "EPA_AQS_KEY",
    "WEBHOOK_SECRET": "WEBHOOK_SHARED_SECRET"
}

for a, canon in ALIASES.items():
    if a in env_all and canon not in env_all:
        env_all[canon] = env_all[a]

found_keys = {k: env_all[k] for k in REGISTRY if env_all.get(k)}

# write canonical env file
env_path = CONF / "luma_live_keys.env"
env_lines = [f"{k}={found_keys[k]}" for k in sorted(found_keys)]
env_path.write_text("\n".join(env_lines) + ("\n" if env_lines else ""), encoding="utf-8")

# current files
live_sources_path   = CONF / "live_sources.json"
live_registry_path  = CONF / "live_source_registry.json"
runtime_path        = CONF / "runtime_control.json"
paper_path          = CONF / "paper_trader_runtime.json"
infra_path          = CONF / "infra_live_runtime.json"

live_sources  = load_json(live_sources_path, {})
runtime       = load_json(runtime_path, {})
paper_runtime = load_json(paper_path, {})
infra_runtime = load_json(infra_path, {})

# preferred paper universe
paper_symbols = [
    "SPY","QQQ","IWM","DIA","NVDA","MSFT","AAPL","AMD","META","AMZN",
    "TSLA","GOOGL","AVGO","SMCI","PLTR","NFLX","BTC/USD","ETH/USD",
    "SOL/USD","XRP/USD","ADA/USD","DOGE/USD","LINK/USD","AVAX/USD",
    "MATIC/USD","DOT/USD"
]

# bind keys into live_sources.json
for key_name, meta in REGISTRY.items():
    src = meta["source"].lower()
    block = live_sources.get(src, {})
    block["enabled"] = key_name in found_keys
    block["api_key_env"] = key_name
    block["source"] = meta["source"]
    block["sector"] = meta["sector"]
    if src == "alpaca":
        block["secret_env"] = "ALPACA_API_SECRET"
    if src == "kraken":
        block["secret_env"] = "KRAKEN_API_SECRET"
    if src == "epa_aqs":
        block["email_env"] = "EPA_AQS_EMAIL"
        block["key_env"] = "EPA_AQS_KEY"
        block["api_key_env"] = "EPA_AQS_KEY"
    live_sources[src] = block

save_json(live_sources_path, live_sources)

# build source registry with measured/unmeasured status
data_roots = infra_runtime.get("data_roots", [
    r"C:\LumaTrader\INSTITUTIONAL_STACK_V2\data",
    r"C:\LumaTrader\data",
    str(Path.home() / "iCloudDrive" / "Data sets")
])

def count_matches(source_name, sector):
    keys = [source_name.lower(), sector.lower()]
    total_rows = 0
    matched = []
    for root in data_roots:
        rp = Path(root)
        if not rp.exists():
            continue
        for p in rp.rglob("*"):
            if not p.is_file():
                continue
            nm = p.name.lower()
            if any(k in nm for k in keys):
                try:
                    if p.suffix.lower() == ".csv":
                        rows = max(0, sum(1 for _ in p.open("r", encoding="utf-8", errors="ignore")) - 1)
                    elif p.suffix.lower() == ".json":
                        rows = 1
                    else:
                        rows = 1
                    total_rows += rows
                    matched.append(str(p))
                except Exception:
                    pass
    return total_rows, matched[:10]

registry_rows = []
for key_name, meta in REGISTRY.items():
    src = meta["source"]
    sector = meta["sector"]
    enabled = key_name in found_keys
    rows, matches = count_matches(src, sector)
    if enabled and rows > 0:
        status = "LIVE_KEY_PRESENT"
        evidence_basis = "MEASURED_FILE_MATCH"
        value_basis = "MEASURED"
    elif enabled:
        status = "LIVE_KEY_PRESENT"
        evidence_basis = "KEY_ONLY"
        value_basis = "UNMEASURED"
    else:
        status = "MISSING"
        evidence_basis = "MISSING"
        value_basis = "MISSING"
    registry_rows.append({
        "source": src,
        "sector": sector,
        "status": status,
        "rows": rows,
        "evidence_basis": evidence_basis,
        "value_basis": value_basis,
        "last_probe_utc": now_utc(),
        "env": key_name,
        "enabled": enabled,
        "matched_paths": matches
    })

live_registry = {
    "generated_utc": now_utc(),
    "paper_live_linked": True,
    "sources": registry_rows
}
save_json(live_registry_path, live_registry)

# also write compact truth table
source_truth = {
    "generated_utc": now_utc(),
    "rows": registry_rows
}
save_json(OUT / "source_truth_table.json", source_truth)

# runtime normalize
runtime["mode"] = "paper"
runtime["symbol"] = "UNIVERSE"
runtime["allow_live_orders"] = False
runtime["kill_switch"] = False
runtime["paper_capital_usd"] = float(runtime.get("paper_capital_usd", 200.0) or 200.0)
runtime["max_notional_per_trade_usd"] = float(runtime.get("max_notional_per_trade_usd", 25.0) or 25.0)
runtime["max_daily_loss_usd"] = float(runtime.get("max_daily_loss_usd", 20.0) or 20.0)
runtime["max_open_positions"] = int(runtime.get("max_open_positions", 1) or 1)
runtime["loop_seconds"] = int(runtime.get("loop_seconds", 5) or 5)
save_json(runtime_path, runtime)

paper_runtime["starting_capital_usd"] = float(paper_runtime.get("starting_capital_usd", 100000.0) or 100000.0)
paper_runtime["loop_seconds"] = int(paper_runtime.get("loop_seconds", 300) or 300)
paper_runtime["symbols"] = paper_symbols
paper_runtime["paper_enabled"] = True
save_json(paper_path, paper_runtime)

infra_runtime["loop_seconds"] = int(infra_runtime.get("loop_seconds", 60) or 60)
infra_runtime["data_roots"] = data_roots
save_json(infra_path, infra_runtime)

enabled_sources = [r for r in registry_rows if r["enabled"]]
measured_sources = [r for r in registry_rows if r["enabled"] and r["rows"] > 0]

summary = {
    "generated_utc": now_utc(),
    "runtime_symbol": runtime["symbol"],
    "paper_symbols_count": len(paper_symbols),
    "found_key_names": sorted(list(found_keys.keys())),
    "enabled_registry_sources": len(enabled_sources),
    "measured_sources": len(measured_sources),
    "output_files": [
        str(env_path),
        str(live_sources_path),
        str(live_registry_path),
        str(OUT / "source_truth_table.json"),
        str(OUT / "live_key_routing_summary.json")
    ]
}
save_json(OUT / "live_key_routing_summary.json", summary)

print("")
print("RUNTIME SYMBOL:", runtime["symbol"])
print("PAPER SYMBOLS:", len(paper_symbols))
print("")
print("FOUND KEY NAMES:")
for k in sorted(found_keys):
    print(" -", k)
print("")
print("ENABLED REGISTRY SOURCES:", len(enabled_sources))
print("MEASURED SOURCES:", len(measured_sources))
print("")
print("OUTPUT FILES:")
for p in summary["output_files"]:
    print(" -", p)