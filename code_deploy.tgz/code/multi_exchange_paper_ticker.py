from __future__ import annotations

import argparse
import atexit
import hashlib
import hmac
import json
import os
import subprocess
import sys
import time
import urllib.parse
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from execution.crypto_allocator import optimize_candidate_weights
from execution.crypto_regime_controller import infer_market_regime
import requests


ROOT = Path(r"C:\LumaTrader\INSTITUTIONAL_STACK_V2")
CODE = ROOT / "code"
CONF = ROOT / "config"
OUT = ROOT / "out" / "execution"

RUNTIME_FILE = CONF / "runtime_control.json"
STATUS_FILE = OUT / "multi_exchange_paper_ticker_status.json"
LEDGER_FILE = OUT / "multi_exchange_paper_ticker_ledger.jsonl"
BINANCEUS_PAPER_STATE_FILE = OUT / "binanceus_paper_state.json"
BINANCEUS_PAPER_LEDGER_FILE = OUT / "binanceus_paper_ledger.jsonl"
BINANCEUS_PAPER_SCOREBOARD_FILE = OUT / "binanceus_paper_scoreboard.json"
INSTITUTIONAL_PAPER_REPORT_FILE = OUT / "institutional_crypto_paper_report.json"
INSTITUTIONAL_PAPER_HASH_FILE = OUT / "institutional_crypto_paper_report_sha256.json"
INSTITUTIONAL_PAPER_DASHBOARD_FILE = ROOT / "dashboard" / "institutional_crypto_paper_dashboard.html"
INSTITUTIONAL_PAPER_BRIEF_FILE = OUT / "institutional_crypto_executive_brief.pdf"
LOCK_FILE = CODE / ".multi_exchange_paper_ticker.lock"

DEFAULT_PROFILE = "apex"
PROFILE_PRESETS: Dict[str, Dict[str, Any]] = {
    "hybrid": {
        "max_positions": 6,
        "max_scan_symbols": 300,
        "base_risk_fraction": 0.07,
        "allocator_mode": "scientific_hybrid",
        "max_single_position_pct": 0.22,
        "max_gross_heat_pct": 0.70,
        "target_position_vol_pct": 0.035,
        "uncertainty_penalty_k": 1.20,
        "min_diversified_slots": 4,
        "vol_scalar_floor": 0.45,
        "vol_scalar_ceiling": 1.20,
        "moon_trigger": 0.014,
        "entry_min_notional_usd": 30.0,
        "entry_max_risk_fraction": 0.22,
        "tp_moon": 0.018,
        "tp_fallback": 0.010,
        "sl": -0.007,
        "timeout_cycles": 12,
        "hybrid_weight_base": 0.58,
        "hybrid_weight_breadth_k": 0.30,
        "min_edge": 0.04,
        "min_pct24": 0.03,
        "min_quote_volume_usd": 150.0,
    },
    "advanced": {
        "max_positions": 8,
        "max_scan_symbols": 500,
        "base_risk_fraction": 0.085,
        "allocator_mode": "scientific_hybrid",
        "max_single_position_pct": 0.20,
        "max_gross_heat_pct": 0.72,
        "target_position_vol_pct": 0.038,
        "uncertainty_penalty_k": 1.15,
        "min_diversified_slots": 5,
        "vol_scalar_floor": 0.45,
        "vol_scalar_ceiling": 1.22,
        "moon_trigger": 0.010,
        "entry_min_notional_usd": 40.0,
        "entry_max_risk_fraction": 0.24,
        "tp_moon": 0.022,
        "tp_fallback": 0.012,
        "sl": -0.008,
        "timeout_cycles": 16,
        "hybrid_weight_base": 0.64,
        "hybrid_weight_breadth_k": 0.45,
        "min_edge": 0.05,
        "min_pct24": 0.04,
        "min_quote_volume_usd": 250.0,
    },
    "hyperfire": {
        "max_positions": 10,
        "max_scan_symbols": 700,
        "base_risk_fraction": 0.16,
        "allocator_mode": "scientific_hybrid",
        "max_single_position_pct": 0.18,
        "max_gross_heat_pct": 0.78,
        "target_position_vol_pct": 0.045,
        "uncertainty_penalty_k": 1.00,
        "min_diversified_slots": 6,
        "vol_scalar_floor": 0.40,
        "vol_scalar_ceiling": 1.25,
        "moon_trigger": 0.004,
        "entry_min_notional_usd": 20.0,
        "entry_max_risk_fraction": 0.30,
        "tp_moon": 0.008,
        "tp_fallback": 0.005,
        "sl": -0.010,
        "timeout_cycles": 1,
        "hybrid_weight_base": 0.70,
        "hybrid_weight_breadth_k": 0.55,
        "min_edge": 0.07,
        "min_pct24": 0.08,
        "min_quote_volume_usd": 500.0,
    },
    "apex": {
        "max_positions": 12,
        "max_scan_symbols": 2500,
        "base_risk_fraction": 0.30,
        "allocator_mode": "scientific_hybrid",
        "max_single_position_pct": 0.16,
        "max_gross_heat_pct": 0.82,
        "target_position_vol_pct": 0.050,
        "uncertainty_penalty_k": 0.95,
        "min_diversified_slots": 8,
        "vol_scalar_floor": 0.35,
        "vol_scalar_ceiling": 1.25,
        "moon_trigger": 0.003,
        "entry_min_notional_usd": 25.0,
        "entry_max_risk_fraction": 1.00,
        "tp_moon": 0.010,
        "tp_fallback": 0.006,
        "sl": -0.012,
        "timeout_cycles": 1,
        "hybrid_weight_base": 0.78,
        "hybrid_weight_breadth_k": 0.60,
        "min_edge": 0.08,
        "min_pct24": 0.10,
        "min_quote_volume_usd": 1200.0,
        "entry_mode": "capital_ladder",
        "ladder_edge_tier1": 0.22,
        "ladder_frac_tier1": 0.55,
        "ladder_edge_tier2": 0.16,
        "ladder_frac_tier2": 0.32,
        "ladder_edge_tier3": 0.10,
        "ladder_frac_tier3": 0.18,
        "ladder_frac_floor": 0.06,
        "ladder_top1_frac": 0.55,
        "ladder_top2_frac": 0.28,
    },
    # ── BREAKOUT ─────────────────────────────────────────────────────────────────
    # Detects coins sitting near 24h high with accelerating trade density.
    # Fires BEFORE the blow-off, not after. Low volume floor kept high enough
    # to have an exit. Chase penalty kills anything already up >30%.
    "breakout": {
        "max_positions": 6,
        "max_scan_symbols": 800,
        "base_risk_fraction": 0.35,
        "allocator_mode": "scientific_hybrid",
        "max_single_position_pct": 0.18,
        "max_gross_heat_pct": 0.74,
        "target_position_vol_pct": 0.042,
        "uncertainty_penalty_k": 1.05,
        "min_diversified_slots": 4,
        "vol_scalar_floor": 0.40,
        "vol_scalar_ceiling": 1.20,
        "moon_trigger": 0.002,
        "entry_min_notional_usd": 50.0,
        "entry_max_risk_fraction": 1.00,
        "tp_moon": 0.018,
        "tp_fallback": 0.010,
        "sl": -0.009,
        "timeout_cycles": 4,
        "hybrid_weight_base": 0.88,
        "hybrid_weight_breadth_k": 0.40,
        "min_edge": 0.09,
        "min_pct24": 0.0,
        "max_pct24": 0.30,
        "min_quote_volume_usd": 250.0,
        "min_near_high": 0.75,
        "min_r2": 0.0005,
        "reentry_cooldown_cycles": 8,
        "entry_mode": "capital_ladder",
        "score_regime": "breakout",
        "ladder_edge_tier1": 0.28,
        "ladder_frac_tier1": 0.58,
        "ladder_edge_tier2": 0.18,
        "ladder_frac_tier2": 0.34,
        "ladder_edge_tier3": 0.10,
        "ladder_frac_tier3": 0.20,
        "ladder_frac_floor": 0.08,
        "ladder_top1_frac": 0.58,
        "ladder_top2_frac": 0.30,
    },
}

KEY_PATHS = [
    CONF / "luma_live_keys.env",
    CONF / "live_keys.env",
    CONF / "keys.env",
    ROOT / "code" / "execution" / "config" / "luma_live_keys.env",
    ROOT / "code" / "execution" / "config" / "live_keys.env",
    ROOT / "code" / "execution" / "config" / "keys.env",
]


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def _pid_is_alive(pid: int) -> bool:
    if pid <= 0:
        return False

    if os.name == "nt":
        try:
            proc = subprocess.run(
                ["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"],
                capture_output=True,
                text=True,
                check=False,
            )
            out = (proc.stdout or "").strip().lower()
            if not out or "no tasks are running" in out:
                return False
            return str(pid) in out
        except Exception:
            return False

    try:
        os.kill(pid, 0)
        return True
    except PermissionError:
        return True
    except Exception:
        return False


def acquire_single_instance_lock(profile: str) -> tuple[bool, str]:
    LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "pid": os.getpid(),
        "started_utc": now_utc(),
        "script": "multi_exchange_paper_ticker.py",
        "profile": profile,
    }

    # Atomic create prevents race conditions between concurrent launches.
    def _try_create() -> tuple[bool, str]:
        flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
        fd = os.open(str(LOCK_FILE), flags)
        try:
            os.write(fd, json.dumps(payload, indent=2).encode("utf-8"))
        finally:
            os.close(fd)
        return True, "acquired"

    try:
        return _try_create()
    except FileExistsError:
        pass
    except Exception as exc:
        return False, f"lock_create_error={exc}"

    try:
        existing = json.loads(LOCK_FILE.read_text(encoding="utf-8"))
        existing_pid = int(existing.get("pid", 0))
    except Exception:
        existing_pid = 0

    if _pid_is_alive(existing_pid):
        return False, f"existing_pid={existing_pid}"

    try:
        LOCK_FILE.unlink()
    except Exception:
        return False, "stale_lock_unremovable"

    try:
        return _try_create()
    except FileExistsError:
        return False, "race_lost"
    except Exception as exc:
        return False, f"lock_recreate_error={exc}"


def release_single_instance_lock() -> None:
    try:
        if not LOCK_FILE.exists():
            return
        data = json.loads(LOCK_FILE.read_text(encoding="utf-8"))
        if int(data.get("pid", 0)) == os.getpid():
            LOCK_FILE.unlink()
    except Exception:
        pass


def is_current_lock_owner() -> bool:
    try:
        if not LOCK_FILE.exists():
            return False
        data = json.loads(LOCK_FILE.read_text(encoding="utf-8"))
        return int(data.get("pid", 0)) == os.getpid()
    except Exception:
        return False


def load_json(path: Path, default: Any) -> Any:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default


def save_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def append_jsonl(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(payload, ensure_ascii=False) + "\n")


def sha256_file(path: Path) -> str:
    if not path.exists():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_env_file(path: Path) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if not path.exists():
        return out
    try:
        for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            row = raw.strip()
            if not row or row.startswith("#") or "=" not in row:
                continue
            key, value = row.split("=", 1)
            out[key.strip()] = value.strip().strip('"').strip("'")
    except Exception:
        return {}
    return out


def hydrate_live_keys() -> Dict[str, Any]:
    hydrated = []
    source = None
    for path in KEY_PATHS:
        env = load_env_file(path)
        if not env:
            continue
        source = str(path)
        for key, value in env.items():
            if value and not os.getenv(key, "").strip():
                os.environ[key] = value
                hydrated.append(key)
        if hydrated:
            break
    return {
        "source": source,
        "hydrated_count": len(hydrated),
        "hydrated_keys": sorted(hydrated),
    }


def force_paper_mode() -> Dict[str, Any]:
    runtime = load_json(RUNTIME_FILE, {})
    before_mode = runtime.get("mode")
    before_live = runtime.get("allow_live_orders")

    runtime["mode"] = "paper"
    runtime["allow_live_orders"] = False
    runtime.setdefault("paper_enabled", True)
    save_json(RUNTIME_FILE, runtime)

    return {
        "before_mode": before_mode,
        "before_allow_live_orders": before_live,
        "after_mode": runtime.get("mode"),
        "after_allow_live_orders": runtime.get("allow_live_orders"),
    }


def _get(url: str, timeout: int = 10, params: Dict[str, Any] | None = None, headers: Dict[str, str] | None = None) -> Dict[str, Any]:
    try:
        resp = requests.get(url, params=params, headers=headers, timeout=timeout)
        resp.raise_for_status()
        return {"ok": True, "status": resp.status_code, "data": resp.json()}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def _binance_sign(params: Dict[str, Any], secret: str) -> str:
    query = urllib.parse.urlencode(params)
    return hmac.new(secret.encode("utf-8"), query.encode("utf-8"), hashlib.sha256).hexdigest()


def kraken_snapshot() -> Dict[str, Any]:
    res = _get("https://api.kraken.com/0/public/Ticker", params={"pair": "XBTUSD"}, timeout=10)
    if not res.get("ok"):
        return {"ok": False, "error": res.get("error")}
    data = res.get("data", {})
    result = data.get("result", {}) if isinstance(data, dict) else {}
    if not result:
        return {"ok": False, "error": "No result from Kraken"}
    first_key = next(iter(result.keys()))
    row = result.get(first_key, {})
    price = None
    if isinstance(row, dict):
        c = row.get("c")
        if isinstance(c, list) and c:
            try:
                price = float(c[0])
            except Exception:
                price = None
    return {"ok": True, "pair": "XBT/USD", "price": price}


def binance_snapshot(api_url: str) -> Dict[str, Any]:
    res = _get(f"{api_url}/api/v3/ticker/price", params={"symbol": "BTCUSDT"}, timeout=10)
    if not res.get("ok"):
        return {"ok": False, "api_url": api_url, "error": res.get("error")}
    row = res.get("data", {})
    price = None
    try:
        price = float(row.get("price"))
    except Exception:
        pass
    return {"ok": True, "api_url": api_url, "symbol": "BTCUSDT", "price": price}


def binanceus_private_account_snapshot() -> Dict[str, Any]:
    key = os.getenv("BINANCE_API_KEY", "").strip()
    secret = os.getenv("BINANCE_API_SECRET", "").strip()
    api_url = "https://api.binance.us"

    if not key or not secret:
        return {
            "ok": False,
            "api_url": api_url,
            "error": "Missing BINANCE_API_KEY/BINANCE_API_SECRET",
        }

    params: Dict[str, Any] = {
        "timestamp": int(time.time() * 1000),
        "recvWindow": 5000,
    }
    params["signature"] = _binance_sign(params, secret)
    headers = {"X-MBX-APIKEY": key}

    try:
        resp = requests.get(f"{api_url}/api/v3/account", params=params, headers=headers, timeout=12)
        resp.raise_for_status()
        data = resp.json()
        balances = data.get("balances", []) if isinstance(data, dict) else []
        nonzero = []
        for row in balances:
            try:
                free = float(row.get("free", 0.0))
                locked = float(row.get("locked", 0.0))
            except Exception:
                continue
            if abs(free) > 0 or abs(locked) > 0:
                nonzero.append(
                    {
                        "asset": row.get("asset"),
                        "free": free,
                        "locked": locked,
                    }
                )
        return {
            "ok": True,
            "api_url": api_url,
            "can_trade": bool(data.get("canTrade", False)),
            "account_type": data.get("accountType"),
            "nonzero_balances": nonzero[:12],
            "nonzero_balance_count": len(nonzero),
        }
    except Exception as exc:
        return {
            "ok": False,
            "api_url": api_url,
            "error": str(exc),
        }


def _f(v: Any, default: float = 0.0) -> float:
    try:
        return float(v)
    except Exception:
        return default


def _i(v: Any, default: int = 0) -> int:
    try:
        return int(v)
    except Exception:
        return default


def _binanceus_24h_snapshot() -> Dict[str, Any]:
    url = "https://api.binance.us/api/v3/ticker/24hr"
    try:
        resp = requests.get(url, timeout=15)
        resp.raise_for_status()
        rows = resp.json()
        if not isinstance(rows, list):
            return {"ok": False, "error": "Unexpected payload"}
        return {"ok": True, "rows": rows}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def _kraken_symbol_to_usd_pair(raw: str) -> str:
    sym = str(raw or "").upper().replace("/", "").replace("-", "").replace("_", "")
    sym = sym.replace("XBT", "BTC")
    if sym.endswith("USDT") or sym.endswith("USDC"):
        return sym
    if sym.endswith("USD"):
        return sym
    return ""


def _kraken_24h_snapshot(max_pairs: int) -> Dict[str, Any]:
    pairs_payload = _get("https://api.kraken.com/0/public/AssetPairs", timeout=20)
    if not pairs_payload.get("ok"):
        return {"ok": False, "error": f"assetpairs:{pairs_payload.get('error')}"}

    result = pairs_payload.get("data", {}).get("result", {})
    if not isinstance(result, dict):
        return {"ok": False, "error": "assetpairs_payload_invalid"}

    ws_pairs: List[str] = []
    symbol_map: Dict[str, str] = {}
    for pair_key, row in result.items():
        if not isinstance(row, dict):
            continue
        ws = str(row.get("wsname", "") or "").upper().strip()
        if not ws or "/" not in ws:
            continue
        quote = ws.split("/")[-1]
        if quote not in {"USD", "USDT", "USDC"}:
            continue
        req_pair = ws.replace("/", "")
        ws_pairs.append(req_pair)
        norm_symbol = _kraken_symbol_to_usd_pair(ws)
        if norm_symbol:
            symbol_map[str(pair_key).upper()] = norm_symbol
            altname = str(row.get("altname", "") or "").upper().strip()
            if altname:
                symbol_map[altname] = norm_symbol
            symbol_map[req_pair] = norm_symbol

    if not ws_pairs:
        return {"ok": False, "error": "no_kraken_usd_pairs"}

    # Kraken accepts comma-delimited pair list; cap payload to stay responsive.
    pair_arg = ",".join(ws_pairs[: max(50, min(max_pairs, 500))])
    ticker_payload = _get("https://api.kraken.com/0/public/Ticker", params={"pair": pair_arg}, timeout=25)
    if not ticker_payload.get("ok"):
        return {"ok": False, "error": f"ticker:{ticker_payload.get('error')}"}

    tickers = ticker_payload.get("data", {}).get("result", {})
    if not isinstance(tickers, dict):
        return {"ok": False, "error": "ticker_payload_invalid"}

    rows: List[Dict[str, Any]] = []
    for ticker_key, row in tickers.items():
        if not isinstance(row, dict):
            continue
        symbol = symbol_map.get(str(ticker_key).upper(), "")
        if not symbol:
            wsname = str(row.get("wsname", "") or "")
            symbol = _kraken_symbol_to_usd_pair(wsname)
        if not symbol:
            continue
        close_px = _f((row.get("c") or [0.0])[0], 0.0)
        open_px = _f(row.get("o"), close_px)
        if close_px <= 0.0:
            continue
        pct = ((close_px / max(open_px, 1e-9)) - 1.0) * 100.0
        vol_base = _f((row.get("v") or [0.0, 0.0])[1], 0.0)
        vwap_24h = _f((row.get("p") or [0.0, close_px])[1], close_px)
        quote_volume = vol_base * max(vwap_24h, 0.0)
        high_px = _f((row.get("h") or [close_px, close_px])[1], close_px)
        low_px = _f((row.get("l") or [close_px, close_px])[1], close_px)
        count_24h = _f((row.get("t") or [0.0, 0.0])[1], 0.0)
        rows.append({
            "symbol": symbol,
            "lastPrice": close_px,
            "priceChangePercent": pct,
            "quoteVolume": quote_volume,
            "highPrice": high_px,
            "lowPrice": low_px,
            "count": count_24h,
            "venue": "kraken",
        })

    return {"ok": True, "rows": rows}


def _build_unified_market_rows(max_scan: int) -> Dict[str, Any]:
    bus = _binanceus_24h_snapshot()
    krk = _kraken_24h_snapshot(max_scan)

    bus_rows = bus.get("rows", []) if isinstance(bus, dict) else []
    krk_rows = krk.get("rows", []) if isinstance(krk, dict) else []
    if not isinstance(bus_rows, list):
        bus_rows = []
    if not isinstance(krk_rows, list):
        krk_rows = []

    merged: Dict[str, Dict[str, Any]] = {}
    for row in bus_rows:
        if not isinstance(row, dict):
            continue
        symbol = str(row.get("symbol", "")).upper().strip()
        if not symbol:
            continue
        cpy = dict(row)
        cpy.setdefault("venue", "binanceus")
        merged[symbol] = cpy
    for row in krk_rows:
        if not isinstance(row, dict):
            continue
        symbol = str(row.get("symbol", "")).upper().strip()
        if not symbol:
            continue
        incoming_qv = _f(row.get("quoteVolume"), 0.0)
        current_qv = _f(merged.get(symbol, {}).get("quoteVolume"), 0.0)
        if symbol not in merged or incoming_qv > current_qv:
            merged[symbol] = dict(row)

    rows = list(merged.values())
    return {
        "ok": bool(rows),
        "rows": rows,
        "errors": {
            "binanceus": bus.get("error") if isinstance(bus, dict) else "unknown",
            "kraken": krk.get("error") if isinstance(krk, dict) else "unknown",
        },
        "venue_counts": {
            "binanceus": len(bus_rows),
            "kraken": len(krk_rows),
            "merged": len(rows),
        },
    }


def _update_symbol_history(history: Dict[str, List[float]], market_rows: List[Dict[str, Any]], keep: int = 20) -> None:
    for row in market_rows:
        sym = str(row.get("symbol", "")).upper().strip()
        if not sym:
            continue
        px = _f(row.get("lastPrice"), 0.0)
        if px <= 0.0:
            continue
        bucket = history.setdefault(sym, [])
        bucket.append(px)
        if len(bucket) > keep:
            del bucket[:-keep]


def _pct(prices: List[float], lookback: int) -> float:
    if len(prices) <= lookback or lookback <= 0:
        return 0.0
    p0 = _f(prices[-(lookback + 1)], 0.0)
    p1 = _f(prices[-1], 0.0)
    if p0 <= 0:
        return 0.0
    return (p1 / p0) - 1.0


def _recent_volatility(prices: List[float]) -> float:
    if not isinstance(prices, list) or len(prices) < 4:
        return 0.0
    returns: List[float] = []
    for idx in range(1, len(prices)):
        p0 = _f(prices[idx - 1], 0.0)
        p1 = _f(prices[idx], 0.0)
        if p0 > 0.0 and p1 > 0.0:
            returns.append(abs((p1 / p0) - 1.0))
    if not returns:
        return 0.0
    return sum(returns) / len(returns)


def _score_candidates(
    history: Dict[str, List[float]],
    market_rows: List[Dict[str, Any]],
    max_scan: int,
) -> Dict[str, Any]:
    ranked = []

    filtered = []
    for row in market_rows:
        sym = str(row.get("symbol", "")).upper().strip()
        if not (sym.endswith("USDT") or sym.endswith("USD") or sym.endswith("USDC")):
            continue
        quote_vol = _f(row.get("quoteVolume"), 0.0)
        last_px = _f(row.get("lastPrice"), 0.0)
        if quote_vol <= 0.0 or last_px <= 0.0:
            continue
        filtered.append((quote_vol, row))

    filtered.sort(key=lambda x: x[0], reverse=True)
    scan_rows = [row for _, row in filtered[: max(max_scan, 20)]]

    for row in scan_rows:
        sym = str(row.get("symbol", "")).upper().strip()
        prices = history.get(sym, [])
        pct24 = _f(row.get("priceChangePercent"), 0.0) / 100.0
        liq = _f(row.get("quoteVolume"), 0.0)

        if len(prices) < 6:
            # Warmup scoring: rely on 24h drift + liquidity until local tick history fills.
            r2 = pct24 * 0.25
            r4 = pct24 * 0.5
            r8 = pct24
            accel = 0.0
        else:
            r2 = _pct(prices, 2)
            r4 = _pct(prices, 4)
            r8 = _pct(prices, 8)
            accel = r2 - r4

        current_px = _f(row.get("lastPrice"), 0.0)
        high_px = _f(row.get("highPrice"), current_px)
        low_px = _f(row.get("lowPrice"), current_px)
        if current_px <= 0.0:
            continue
        if high_px <= 0.0:
            high_px = current_px
        if low_px <= 0.0:
            low_px = current_px
        if high_px < low_px:
            high_px, low_px = low_px, high_px
        trade_count = _f(row.get("count"), 0.0)
        range_size = max(high_px - low_px, 1e-12)
        near_high = min(max((current_px - low_px) / range_size, 0.0), 1.0)  # 0=at low, 1=at high
        # Trade density: trades-per-million-USD (high = lots of small accumulation orders)
        trade_density = min(trade_count / max(liq / 1_000_000.0, 0.001), 50_000.0) / 50_000.0
        # Breakout score: near-high position + acceleration + trade density; penalise chase
        chase_penalty = max(0.0, pct24 - 0.30) * 12.0
        breakout_score = (
            near_high * 6.0
            + max(accel, 0.0) * 5.0
            + max(r2, 0.0) * 4.0
            + max(pct24, 0.0) * 2.0
            + trade_density * 3.0
            - chase_penalty
            + min(liq / 1_000_000.0, 10.0) * 0.05
        )

        # Moonshot regime: prioritize fresh acceleration + positive drift + liquidity.
        moon_score = (
            max(r2, 0.0) * 5.0
            + max(r4, 0.0) * 3.0
            + max(r8, 0.0) * 2.0
            + max(accel, 0.0) * 4.0
            + max(pct24, 0.0) * 0.5
            + min(liq / 1_000_000.0, 8.0) * 0.05
        )

        # Fallback regime: rebound/continuation on liquid symbols when moon signals are thin.
        fallback_score = (
            max(-r4, 0.0) * 2.0
            + max(r2, 0.0) * 2.5
            + max(accel, 0.0) * 2.0
            + max(pct24, -0.10) * 0.2
            + min(liq / 1_000_000.0, 8.0) * 0.05
        )

        ranked.append(
            {
                "symbol": sym,
                "price": _f(row.get("lastPrice"), 0.0),
                "quote_volume": liq,
                "r2": r2,
                "r4": r4,
                "r8": r8,
                "accel": accel,
                "pct24": pct24,
                "near_high": near_high,
                "trade_density": trade_density,
                "moon_score": moon_score,
                "fallback_score": fallback_score,
                "breakout_score": breakout_score,
            }
        )

    ranked_moon = sorted(ranked, key=lambda x: x["moon_score"], reverse=True)
    ranked_fallback = sorted(ranked, key=lambda x: x["fallback_score"], reverse=True)
    ranked_breakout = sorted(ranked, key=lambda x: x["breakout_score"], reverse=True)
    breadth_pos_pct24 = 0.0
    if ranked:
        breadth_pos_pct24 = len([x for x in ranked if _f(x.get("pct24"), 0.0) > 0.0]) / len(ranked)

    return {
        "scan_count": len(scan_rows),
        "scored_count": len(ranked),
        "breadth_pos_pct24": breadth_pos_pct24,
        "moon_ranked": ranked_moon,
        "fallback_ranked": ranked_fallback,
        "breakout_ranked": ranked_breakout,
        "moon_top": ranked_moon[:20],
        "fallback_top": ranked_fallback[:20],
        "breakout_top": ranked_breakout[:20],
    }


def _calc_metrics(series: List[float]) -> Dict[str, Any]:
    n = len(series)
    wins = len([x for x in series if x > 0])
    losses = len([x for x in series if x < 0])
    total = sum(series) if series else 0.0
    avg = (total / n) if n else 0.0
    gross_win = sum([x for x in series if x > 0])
    gross_loss = abs(sum([x for x in series if x < 0]))
    pf = gross_win / gross_loss if gross_loss > 0 else (999.0 if gross_win > 0 else 0.0)
    return {
        "n": n,
        "wins": wins,
        "losses": losses,
        "win_rate": (wins / n) if n else 0.0,
        "total_pnl_usd": total,
        "avg_pnl_usd": avg,
        "profit_factor": pf,
    }


def _update_scoreboard(events: List[Dict[str, Any]]) -> Dict[str, Any]:
    board = load_json(
        BINANCEUS_PAPER_SCOREBOARD_FILE,
        {
            "updated_utc": now_utc(),
            "pnl_history_usd": [],
            "regime_pnl_history_usd": {"moonshot": [], "fallback": []},
            "totals": {},
            "regimes": {},
        },
    )

    pnl_hist = board.get("pnl_history_usd", [])
    if not isinstance(pnl_hist, list):
        pnl_hist = []

    reg_hist = board.get("regime_pnl_history_usd", {})
    if not isinstance(reg_hist, dict):
        reg_hist = {}
    reg_hist.setdefault("moonshot", [])
    reg_hist.setdefault("fallback", [])

    for ev in events:
        if ev.get("event_type") != "binanceus_paper_fill" or ev.get("side") != "sell":
            continue
        pnl = _f(ev.get("pnl_usd"), 0.0)
        pnl_hist.append(pnl)
        regime = str(ev.get("regime", "fallback"))
        if regime not in reg_hist:
            reg_hist[regime] = []
        reg_hist[regime].append(pnl)

    keep = 400
    if len(pnl_hist) > keep:
        pnl_hist = pnl_hist[-keep:]
    for k in list(reg_hist.keys()):
        arr = reg_hist.get(k, [])
        if isinstance(arr, list) and len(arr) > keep:
            reg_hist[k] = arr[-keep:]

    totals = _calc_metrics(pnl_hist)
    regimes = {k: _calc_metrics(v if isinstance(v, list) else []) for k, v in reg_hist.items()}

    board.update(
        {
            "updated_utc": now_utc(),
            "pnl_history_usd": pnl_hist,
            "regime_pnl_history_usd": reg_hist,
            "totals": totals,
            "regimes": regimes,
        }
    )
    save_json(BINANCEUS_PAPER_SCOREBOARD_FILE, board)
    return board


def _default_binanceus_paper_state(profile_key: str, preset: Dict[str, Any], seed_capital: float, price: float | None) -> Dict[str, Any]:
    seeded_cash = round(max(seed_capital, 1000.0), 6)
    return {
        "started_utc": now_utc(),
        "cash_usd": seeded_cash,
        "initial_cash_usd": seeded_cash,
        "seed_capital_usd": seeded_cash,
        "realized_pnl_usd": 0.0,
        "trade_count": 0,
        "wins": 0,
        "losses": 0,
        "last_action": "INIT",
        "last_price": price,
        "equity_usd": seeded_cash,
        "positions": {},
        "recent_exits": {},
        "history": {},
        "last_regime": "moonshot",
        "last_candidates": [],
        "scan_count": 0,
        "scored_count": 0,
        "max_positions": int(preset.get("max_positions", 6)),
        "max_scan_symbols": int(preset.get("max_scan_symbols", 300)),
        "base_risk_fraction": float(preset.get("base_risk_fraction", 0.07)),
        "profile": profile_key,
    }


def build_institutional_crypto_paper_report(payload: Dict[str, Any], seed_capital: float, reset_state: bool) -> Dict[str, Any]:
    engine = payload.get("binanceus_paper_engine", {}) if isinstance(payload, dict) else {}
    state = engine.get("state", {}) if isinstance(engine, dict) else {}
    scoreboard_totals = engine.get("scoreboard_totals", {}) if isinstance(engine, dict) else {}
    quality_gate = engine.get("quality_gate", {}) if isinstance(engine, dict) else {}
    event = engine.get("event", {}) if isinstance(engine, dict) else {}
    hybrid_top = engine.get("hybrid_top", []) if isinstance(engine, dict) else []
    fallback_top = engine.get("fallback_top", []) if isinstance(engine, dict) else []
    moon_top = engine.get("moon_top", []) if isinstance(engine, dict) else []
    positions = state.get("positions", {}) if isinstance(state, dict) else {}
    scientific_allocator = state.get("scientific_allocator", {}) if isinstance(state, dict) else {}
    regime_controller = state.get("regime_controller", {}) if isinstance(state, dict) else {}

    initial_equity = _f(state.get("initial_cash_usd"), max(seed_capital, 1000.0))
    equity = _f(state.get("equity_usd"), initial_equity)
    cash = _f(state.get("cash_usd"), initial_equity)
    realized = _f(state.get("realized_pnl_usd"), 0.0)
    unrealized = _f(state.get("unrealized_pnl_usd"), 0.0)
    gross = _f(state.get("gross_position_value_usd"), 0.0)
    equity_return = ((equity / initial_equity) - 1.0) if initial_equity > 0 else 0.0

    report = {
        "generated_utc": now_utc(),
        "mode": "seeded_institutional_crypto_paper",
        "profile": payload.get("profile"),
        "seed_request": {
            "requested_seed_capital_usd": round(max(seed_capital, 1000.0), 6),
            "reset_state": bool(reset_state),
            "active_initial_cash_usd": round(initial_equity, 6),
        },
        "portfolio": {
            "cash_usd": round(cash, 6),
            "gross_position_value_usd": round(gross, 6),
            "equity_usd": round(equity, 6),
            "realized_pnl_usd": round(realized, 6),
            "unrealized_pnl_usd": round(unrealized, 6),
            "return_pct": round(equity_return, 6),
            "positions_open": len(positions),
        },
        "decision_audit": {
            "cycle": payload.get("cycle"),
            "regime": engine.get("regime"),
            "hybrid_weight": engine.get("hybrid_weight"),
            "breadth_pos_pct24": engine.get("breadth_pos_pct24"),
            "scan_count": engine.get("scan_count"),
            "scored_count": engine.get("scored_count"),
            "last_action": event.get("action"),
            "last_event": event,
            "scientific_allocator": scientific_allocator,
            "regime_controller": regime_controller,
            "quality_gate": quality_gate,
            "top_candidates": {
                "hybrid": hybrid_top[:5],
                "moon": moon_top[:5],
                "fallback": fallback_top[:5],
            },
        },
        "scoreboard": scoreboard_totals,
        "runtime_guard": payload.get("runtime_guard"),
        "artifacts": {
            "status_file": str(STATUS_FILE),
            "ledger_file": str(BINANCEUS_PAPER_LEDGER_FILE),
            "state_file": str(BINANCEUS_PAPER_STATE_FILE),
            "scoreboard_file": str(BINANCEUS_PAPER_SCOREBOARD_FILE),
            "report_file": str(INSTITUTIONAL_PAPER_REPORT_FILE),
        },
    }
    save_json(INSTITUTIONAL_PAPER_REPORT_FILE, report)

    hashes = {
        "generated_utc": now_utc(),
        "files": [
            {"path": str(STATUS_FILE), "sha256": sha256_file(STATUS_FILE)},
            {"path": str(BINANCEUS_PAPER_LEDGER_FILE), "sha256": sha256_file(BINANCEUS_PAPER_LEDGER_FILE)},
            {"path": str(BINANCEUS_PAPER_STATE_FILE), "sha256": sha256_file(BINANCEUS_PAPER_STATE_FILE)},
            {"path": str(BINANCEUS_PAPER_SCOREBOARD_FILE), "sha256": sha256_file(BINANCEUS_PAPER_SCOREBOARD_FILE)},
            {"path": str(INSTITUTIONAL_PAPER_REPORT_FILE), "sha256": sha256_file(INSTITUTIONAL_PAPER_REPORT_FILE)},
        ],
    }
    save_json(INSTITUTIONAL_PAPER_HASH_FILE, hashes)
    report["artifact_hash_file"] = str(INSTITUTIONAL_PAPER_HASH_FILE)
    report["artifact_hashes"] = hashes["files"]
    save_json(INSTITUTIONAL_PAPER_REPORT_FILE, report)
    return report


def run_binanceus_paper_logic(price: float | None, cycle: int, profile: str, seed_capital: float, reset_state: bool = False) -> Dict[str, Any]:
    profile_key = profile if profile in PROFILE_PRESETS else DEFAULT_PROFILE
    preset = PROFILE_PRESETS.get(profile_key, PROFILE_PRESETS[DEFAULT_PROFILE])
    default_state = _default_binanceus_paper_state(profile_key, preset, seed_capital, price)

    state = default_state if reset_state else load_json(BINANCEUS_PAPER_STATE_FILE, default_state)

    cash = _f(state.get("cash_usd"), _f(default_state.get("cash_usd"), 10000.0))
    realized = _f(state.get("realized_pnl_usd"), 0.0)
    trades = _i(state.get("trade_count"), 0)
    wins = _i(state.get("wins"), 0)
    losses = _i(state.get("losses"), 0)
    max_positions = max(_i(state.get("max_positions"), _i(preset.get("max_positions"), 6)), 1)
    max_scan = max(_i(state.get("max_scan_symbols"), _i(preset.get("max_scan_symbols"), 300)), 25)
    base_risk = min(max(_f(state.get("base_risk_fraction"), _f(preset.get("base_risk_fraction"), 0.07)), 0.01), 0.30)

    positions = state.get("positions", {})
    if not isinstance(positions, dict):
        positions = {}
    recent_exits = state.get("recent_exits", {})
    if not isinstance(recent_exits, dict):
        recent_exits = {}
    history = state.get("history", {})
    if not isinstance(history, dict):
        history = {}
    abs_cycle = _i(state.get("absolute_cycle"), 0) + 1

    # Legacy migration from previous single-symbol schema.
    legacy_qty = _f(state.get("btc_qty"), 0.0)
    if legacy_qty > 0.0 and (not positions) and price is not None and price > 0:
        cash += legacy_qty * float(price)
    for old_key in ["btc_qty", "avg_entry"]:
        if old_key in state:
            state.pop(old_key, None)

    snap = _build_unified_market_rows(max_scan)
    if not snap.get("ok"):
        event = {
            "timestamp_utc": now_utc(),
            "cycle": cycle,
            "absolute_cycle": abs_cycle,
            "event_type": "binanceus_paper_mark",
            "action": "HOLD",
            "error": snap.get("errors") or snap.get("error"),
        }
        append_jsonl(BINANCEUS_PAPER_LEDGER_FILE, event)
        state.update(
            {
                "last_tick_utc": now_utc(),
                "last_action": "HOLD",
                "last_error": snap.get("errors") or snap.get("error"),
                "positions": positions,
                "history": history,
            }
        )
        save_json(BINANCEUS_PAPER_STATE_FILE, state)
        return {
            "ok": False,
            "state_file": str(BINANCEUS_PAPER_STATE_FILE),
            "ledger_file": str(BINANCEUS_PAPER_LEDGER_FILE),
            "event": event,
            "state": state,
        }

    rows = snap.get("rows", [])
    if not isinstance(rows, list):
        rows = []
    venue_counts = snap.get("venue_counts", {}) if isinstance(snap, dict) else {}

    _update_symbol_history(history, rows, keep=20)
    scored = _score_candidates(history, rows, max_scan=max_scan)

    moon_ranked = scored.get("moon_ranked", []) if isinstance(scored, dict) else []
    fallback_ranked = scored.get("fallback_ranked", []) if isinstance(scored, dict) else []
    breakout_ranked = scored.get("breakout_ranked", []) if isinstance(scored, dict) else []
    moon_top = scored.get("moon_top", []) if isinstance(scored, dict) else []
    fallback_top = scored.get("fallback_top", []) if isinstance(scored, dict) else []
    breadth = _f(scored.get("breadth_pos_pct24"), 0.5)
    moon_trigger = _f(preset.get("moon_trigger"), 0.014)
    moon_ready = bool(moon_top) and _f(moon_top[0].get("moon_score"), 0.0) >= moon_trigger

    score_regime_override = str(preset.get("score_regime", "")).lower()

    base_w = _f(preset.get("hybrid_weight_base"), 0.58)
    breadth_k = _f(preset.get("hybrid_weight_breadth_k"), 0.30)
    hybrid_weight = min(max(base_w + (breadth - 0.5) * breadth_k, 0.20), 0.85)

    if score_regime_override == "breakout":
        hybrid_ranked = breakout_ranked
        regime = "breakout"
    else:
        combined: Dict[str, Dict[str, Any]] = {}
        for row in moon_ranked:
            combined[row["symbol"]] = dict(row)
        for row in fallback_ranked:
            if row["symbol"] not in combined:
                combined[row["symbol"]] = dict(row)

        for sym, row in combined.items():
            row["symbol"] = sym
            row["hybrid_score"] = (hybrid_weight * _f(row.get("moon_score"), 0.0)) + ((1.0 - hybrid_weight) * _f(row.get("fallback_score"), 0.0))

        hybrid_ranked = sorted(list(combined.values()), key=lambda x: x.get("hybrid_score", 0.0), reverse=True)
        regime = "moonshot" if moon_ready else "fallback"

    picks = hybrid_ranked[: max_positions]

    market_price_map: Dict[str, float] = {}
    for row in rows:
        sym = str(row.get("symbol", "")).upper().strip()
        px = _f(row.get("lastPrice"), 0.0)
        if sym and px > 0.0:
            market_price_map[sym] = px

    events: List[Dict[str, Any]] = []

    # Exit logic for open positions.
    for sym in list(positions.keys()):
        pos = positions.get(sym, {})
        qty = _f(pos.get("qty"), 0.0)
        entry = _f(pos.get("entry"), 0.0)
        if qty <= 0.0 or entry <= 0.0:
            positions.pop(sym, None)
            continue
        mark = market_price_map.get(sym)
        if not mark:
            continue

        hold_cycles = max(cycle - _i(pos.get("opened_cycle"), cycle), 0)
        hold_cycles = max(abs_cycle - _i(pos.get("opened_cycle"), abs_cycle), 0)
        pnl_pct = (mark / entry) - 1.0
        tp = _f(preset.get("tp_fallback"), 0.010) if regime == "fallback" else _f(preset.get("tp_moon"), 0.018)
        sl = _f(preset.get("sl"), -0.007)
        timeout = _i(preset.get("timeout_cycles"), 12)
        should_exit = pnl_pct >= tp or pnl_pct <= sl or hold_cycles >= timeout
        if not should_exit:
            continue

        proceeds = qty * mark
        pnl = proceeds - (qty * entry)
        cash += proceeds
        realized += pnl
        trades += 1
        if pnl >= 0:
            wins += 1
        else:
            losses += 1

        ev = {
            "timestamp_utc": now_utc(),
            "cycle": cycle,
            "absolute_cycle": abs_cycle,
            "event_type": "binanceus_paper_fill",
            "side": "sell",
            "symbol": sym,
            "qty": round(qty, 10),
            "fill_price": round(mark, 6),
            "notional_usd": round(proceeds, 4),
            "entry_price": round(entry, 6),
            "pnl_usd": round(pnl, 6),
            "pnl_pct": round(pnl_pct, 6),
            "action": "SELL",
            "reason": "tp_sl_timeout",
            "regime": regime,
        }
        events.append(ev)
        recent_exits[sym] = abs_cycle
        positions.pop(sym, None)

    # Entry logic for top picks.
    held = set(positions.keys())
    slots_left = max(max_positions - len(held), 0)
    gate_min_edge = _f(preset.get("min_edge"), 0.0)
    gate_min_pct24 = _f(preset.get("min_pct24"), -999.0)
    gate_max_pct24 = _f(preset.get("max_pct24"), 9999.0)
    gate_min_qv = _f(preset.get("min_quote_volume_usd"), 0.0)
    gate_min_near_high = _f(preset.get("min_near_high"), 0.0)
    gate_min_r2 = _f(preset.get("min_r2"), -999.0)
    gate_reentry_cooldown = _i(preset.get("reentry_cooldown_cycles"), 0)
    allocator_mode = str(preset.get("allocator_mode", "scientific_hybrid"))
    max_single_position_pct = min(max(_f(preset.get("max_single_position_pct"), 0.22), 0.05), 0.50)
    max_gross_heat_pct = min(max(_f(preset.get("max_gross_heat_pct"), 0.70), max_single_position_pct), 0.95)
    target_position_vol_pct = min(max(_f(preset.get("target_position_vol_pct"), 0.035), 0.005), 0.25)
    uncertainty_penalty_k = min(max(_f(preset.get("uncertainty_penalty_k"), 1.20), 0.0), 5.0)
    min_diversified_slots = max(_i(preset.get("min_diversified_slots"), 4), 1)
    vol_scalar_floor = min(max(_f(preset.get("vol_scalar_floor"), 0.45), 0.10), 1.0)
    vol_scalar_ceiling = max(_f(preset.get("vol_scalar_ceiling"), 1.20), 1.0)
    gate_rejects = {
        "low_edge": 0,
        "low_pct24": 0,
        "low_quote_volume": 0,
        "low_near_high": 0,
        "low_r2": 0,
        "cooldown_reentry": 0,
        "skip_invalid_or_held": 0,
        "skip_bad_price": 0,
        "skip_notional_too_small": 0,
        "single_position_cap": 0,
        "gross_heat_cap": 0,
    }

    current_gross_position_value = 0.0
    for held_sym, held_pos in positions.items():
        held_qty = _f(held_pos.get("qty"), 0.0)
        held_entry = _f(held_pos.get("entry"), 0.0)
        held_mark = market_price_map.get(held_sym, held_entry)
        current_gross_position_value += held_qty * held_mark

    equity_basis = max(cash + current_gross_position_value, 1.0)
    edge_key = "breakout_score" if regime == "breakout" else ("moon_score" if regime == "moonshot" else "fallback_score")
    top_edge = max(_f(picks[0].get(edge_key), 0.0), 1e-9) if picks else 1e-9
    available_heat_pct = max(((equity_basis * max_gross_heat_pct) - current_gross_position_value) / equity_basis, 0.0)
    turnover_reference = state.get("scientific_allocator", {}).get("last_target_weights", {}) if isinstance(state.get("scientific_allocator", {}), dict) else {}
    optimizer_risk_aversion = min(max(_f(preset.get("optimizer_risk_aversion"), 6.0), 0.10), 100.0)
    optimizer_turnover_penalty = min(max(_f(preset.get("optimizer_turnover_penalty"), 0.40), 0.0), 10.0)
    prior_regime_state = state.get("regime_controller", {}) if isinstance(state.get("regime_controller", {}), dict) else {}
    regime_controller = infer_market_regime(history, hybrid_ranked[:20], breadth, prior_state=prior_regime_state)
    regime_heat_multiplier = min(max(_f(regime_controller.get("heat_multiplier"), 1.0), 0.30), 1.20)
    regime_risk_aversion_multiplier = min(max(_f(regime_controller.get("risk_aversion_multiplier"), 1.0), 0.50), 2.50)
    regime_confidence_multiplier = min(max(_f(regime_controller.get("confidence_multiplier"), 1.0), 0.50), 1.50)
    max_single_position_pct = min(max(max_single_position_pct * regime_heat_multiplier, 0.04), 0.50)
    max_gross_heat_pct = min(max(max_gross_heat_pct * regime_heat_multiplier, max_single_position_pct), 0.95)
    available_heat_pct = max(((equity_basis * max_gross_heat_pct) - current_gross_position_value) / equity_basis, 0.0)
    optimizer_risk_aversion *= regime_risk_aversion_multiplier
    candidate_entries: List[Dict[str, Any]] = []

    for pick_idx, pick in enumerate(picks):
        if slots_left <= 0:
            break
        sym = str(pick.get("symbol", "")).upper().strip()
        if not sym or sym in held:
            gate_rejects["skip_invalid_or_held"] += 1
            continue
        px = _f(pick.get("price"), 0.0)
        if px <= 0.0:
            gate_rejects["skip_bad_price"] += 1
            continue

        edge = _f(pick.get("breakout_score" if regime == "breakout" else ("moon_score" if regime == "moonshot" else "fallback_score")), 0.0)
        pct24 = _f(pick.get("pct24"), 0.0)
        r2 = _f(pick.get("r2"), 0.0)
        r4 = _f(pick.get("r4"), 0.0)
        r8 = _f(pick.get("r8"), 0.0)
        qv = _f(pick.get("quote_volume"), 0.0)
        near_high = _f(pick.get("near_high"), 0.0)

        if edge < gate_min_edge:
            gate_rejects["low_edge"] += 1
            continue
        if pct24 < gate_min_pct24:
            gate_rejects["low_pct24"] += 1
            continue
        if pct24 > gate_max_pct24:
            gate_rejects["high_pct24_chase"] = gate_rejects.get("high_pct24_chase", 0) + 1
            continue
        if qv < gate_min_qv:
            gate_rejects["low_quote_volume"] += 1
            continue
        if regime == "breakout" and near_high < gate_min_near_high:
            gate_rejects["low_near_high"] += 1
            continue
        if regime == "breakout" and r2 < gate_min_r2:
            gate_rejects["low_r2"] += 1
            continue
        if regime == "breakout" and gate_reentry_cooldown > 0:
            last_exit_cycle = _i(recent_exits.get(sym), -10_000_000)
            if (abs_cycle - last_exit_cycle) < gate_reentry_cooldown:
                gate_rejects["cooldown_reentry"] += 1
                continue

        risk_frac = min(max(base_risk + edge * 0.05, 0.02), _f(preset.get("entry_max_risk_fraction"), 0.22))
        diversification_slots = max(slots_left, max(min_diversified_slots - len(held), 1))
        alloc_budget = cash / max(diversification_slots, 1)

        ladder_frac = 0.0
        if str(preset.get("entry_mode", "")).lower() == "capital_ladder":
            t1 = _f(preset.get("ladder_edge_tier1"), 0.22)
            t2 = _f(preset.get("ladder_edge_tier2"), 0.16)
            t3 = _f(preset.get("ladder_edge_tier3"), 0.10)
            f1 = _f(preset.get("ladder_frac_tier1"), 1.00)
            f2 = _f(preset.get("ladder_frac_tier2"), 0.50)
            f3 = _f(preset.get("ladder_frac_tier3"), 0.25)
            ff = _f(preset.get("ladder_frac_floor"), 0.08)

            if edge >= t1:
                ladder_frac = f1
            elif edge >= t2:
                ladder_frac = f2
            elif edge >= t3:
                ladder_frac = f3
            else:
                ladder_frac = ff

            # Top-ranked candidates get explicit first-shot capital priority.
            if pick_idx == 0:
                ladder_frac = max(ladder_frac, _f(preset.get("ladder_top1_frac"), ladder_frac))
            elif pick_idx == 1:
                ladder_frac = max(ladder_frac, _f(preset.get("ladder_top2_frac"), ladder_frac))

        if ladder_frac > 0.0:
            raw_notional = cash * ladder_frac
        else:
            raw_notional = min(cash * risk_frac, alloc_budget)

        recent_prices = history.get(sym, []) if isinstance(history.get(sym, []), list) else []
        estimated_vol = max(
            _recent_volatility(recent_prices),
            abs(r2),
            abs(r4) / 2.0,
            abs(r8) / 4.0,
            abs(pct24) / 8.0,
            0.005,
        )
        vol_scalar = min(max(target_position_vol_pct / max(estimated_vol, target_position_vol_pct * 0.50), vol_scalar_floor), vol_scalar_ceiling)
        uncertainty_scalar = 1.0 / (1.0 + uncertainty_penalty_k * max((estimated_vol / max(target_position_vol_pct, 1e-9)) - 1.0, 0.0))
        confidence_scalar = min(max(edge / top_edge, 0.35), 1.0)

        single_position_cap_usd = max(equity_basis * max_single_position_pct, _f(preset.get("entry_min_notional_usd"), 25.0))
        gross_heat_remaining_usd = max((equity_basis * max_gross_heat_pct) - current_gross_position_value, 0.0)
        candidate_entries.append(
            {
                "symbol": sym,
                "price": px,
                "pick": pick,
                "edge": edge,
                "raw_notional_usd": raw_notional,
                "ladder_frac": ladder_frac,
                "estimated_vol": estimated_vol,
                "vol_scalar": vol_scalar,
                "uncertainty_scalar": uncertainty_scalar,
                "confidence_scalar": confidence_scalar,
                "single_position_cap_usd": single_position_cap_usd,
                "gross_heat_remaining_usd": gross_heat_remaining_usd,
                "max_weight_cap_pct": min(single_position_cap_usd / equity_basis, gross_heat_remaining_usd / equity_basis, max_single_position_pct),
                "expected_return": max(edge, 0.0) * confidence_scalar * regime_confidence_multiplier * max(vol_scalar * uncertainty_scalar, 0.10),
            }
        )

    optimizer_result = optimize_candidate_weights(
        candidate_entries,
        available_heat_pct=available_heat_pct,
        max_single_position_pct=max_single_position_pct,
        turnover_reference=turnover_reference,
        risk_aversion=optimizer_risk_aversion,
        turnover_penalty=optimizer_turnover_penalty,
    )
    optimized_weights = optimizer_result.get("weights", {}) if isinstance(optimizer_result, dict) else {}

    for candidate in candidate_entries:
        sym = str(candidate.get("symbol", ""))
        px = _f(candidate.get("price"), 0.0)
        pick = candidate.get("pick", {}) if isinstance(candidate.get("pick", {}), dict) else {}
        edge = _f(candidate.get("edge"), 0.0)
        optimized_weight_pct = max(_f(optimized_weights.get(sym), 0.0), 0.0)
        single_position_cap_usd = _f(candidate.get("single_position_cap_usd"), 0.0)
        gross_heat_remaining_usd = max((equity_basis * max_gross_heat_pct) - current_gross_position_value, 0.0)
        optimized_notional = equity_basis * optimized_weight_pct
        notional = min(optimized_notional, single_position_cap_usd, gross_heat_remaining_usd, cash, _f(candidate.get("raw_notional_usd"), 0.0))
        notional = max(notional, _f(preset.get("entry_min_notional_usd"), 25.0))
        if notional > single_position_cap_usd + 1e-9:
            gate_rejects["single_position_cap"] += 1
            notional = single_position_cap_usd
        if notional > gross_heat_remaining_usd + 1e-9:
            gate_rejects["gross_heat_cap"] += 1
            notional = gross_heat_remaining_usd
        if notional > cash:
            notional = cash
        if notional < 10.0:
            gate_rejects["skip_notional_too_small"] += 1
            continue

        qty = notional / px
        cash -= notional
        current_gross_position_value += notional
        positions[sym] = {
            "qty": qty,
            "entry": px,
            "opened_cycle": abs_cycle,
            "regime": regime,
            "edge": edge,
        }
        trades += 1
        held.add(sym)
        slots_left -= 1

        ev = {
            "timestamp_utc": now_utc(),
            "cycle": cycle,
            "absolute_cycle": abs_cycle,
            "event_type": "binanceus_paper_fill",
            "side": "buy",
            "symbol": sym,
            "qty": round(qty, 10),
            "fill_price": round(px, 6),
            "notional_usd": round(notional, 4),
            "action": "BUY",
            "reason": "ranked_entry",
            "regime": regime,
            "edge": round(edge, 6),
            "target_flip": "100x" if edge >= 0.22 else ("10x" if edge >= 0.16 else ("5x" if edge >= 0.10 else "taper")),
            "rationale": {
                "r2": round(_f(pick.get("r2"), 0.0), 6),
                "r4": round(_f(pick.get("r4"), 0.0), 6),
                "r8": round(_f(pick.get("r8"), 0.0), 6),
                "accel": round(_f(pick.get("accel"), 0.0), 6),
                "pct24": round(_f(pick.get("pct24"), 0.0), 6),
                "quote_volume": round(_f(pick.get("quote_volume"), 0.0), 2),
                "ladder_frac": round(_f(candidate.get("ladder_frac"), 0.0), 6),
                "raw_notional_usd": round(_f(candidate.get("raw_notional_usd"), 0.0), 4),
                "optimized_notional_usd": round(optimized_notional, 4),
                "optimized_weight_pct": round(optimized_weight_pct, 6),
                "estimated_vol_pct": round(_f(candidate.get("estimated_vol"), 0.0), 6),
                "vol_scalar": round(_f(candidate.get("vol_scalar"), 0.0), 6),
                "uncertainty_scalar": round(_f(candidate.get("uncertainty_scalar"), 0.0), 6),
                "confidence_scalar": round(_f(candidate.get("confidence_scalar"), 0.0), 6),
                "single_position_cap_usd": round(single_position_cap_usd, 4),
                "gross_heat_remaining_usd": round(gross_heat_remaining_usd, 4),
                "optimizer_status": str(optimizer_result.get("status", "n/a")),
            },
        }
        events.append(ev)

    # Mark-to-market.
    unrealized = 0.0
    gross_position_value = 0.0
    for sym, pos in positions.items():
        qty = _f(pos.get("qty"), 0.0)
        entry = _f(pos.get("entry"), 0.0)
        mark = market_price_map.get(sym, entry)
        gross_position_value += qty * mark
        unrealized += (qty * mark) - (qty * entry)
    equity = cash + gross_position_value

    # Prevent unbounded state growth in long runs.
    if recent_exits:
        min_cycle_keep = abs_cycle - 1000
        recent_exits = {k: v for k, v in recent_exits.items() if _i(v, 0) >= min_cycle_keep}

    if not events:
        events.append(
            {
                "timestamp_utc": now_utc(),
                "cycle": cycle,
                "absolute_cycle": abs_cycle,
                "event_type": "binanceus_paper_mark",
                "action": "HOLD",
                "regime": regime,
            }
        )

    for ev in events:
        append_jsonl(BINANCEUS_PAPER_LEDGER_FILE, ev)

    scoreboard = _update_scoreboard(events)
    totals = scoreboard.get("totals", {}) if isinstance(scoreboard, dict) else {}

    tune_event = "none"
    if _i(totals.get("n"), 0) >= 12 and cycle % 5 == 0:
        wr = _f(totals.get("win_rate"), 0.0)
        pf = _f(totals.get("profit_factor"), 0.0)
        if wr >= 0.57 and pf >= 1.25:
            base_risk = min(base_risk * 1.08, 0.18)
            max_positions = min(max_positions + 1, max(_i(preset.get("max_positions"), 8) + 2, 4))
            tune_event = "risk_up"
        elif wr <= 0.45 or pf <= 0.90:
            base_risk = max(base_risk * 0.90, 0.02)
            max_positions = max(max_positions - 1, 3)
            tune_event = "risk_down"

    primary_event = events[-1]
    state.update(
        {
            "last_tick_utc": now_utc(),
            "absolute_cycle": abs_cycle,
            "initial_cash_usd": round(_f(state.get("initial_cash_usd"), _f(default_state.get("initial_cash_usd"), cash)), 6),
            "seed_capital_usd": round(_f(state.get("seed_capital_usd"), _f(default_state.get("seed_capital_usd"), cash)), 6),
            "cash_usd": round(cash, 6),
            "realized_pnl_usd": round(realized, 6),
            "unrealized_pnl_usd": round(unrealized, 6),
            "equity_usd": round(equity, 6),
            "gross_position_value_usd": round(gross_position_value, 6),
            "trade_count": trades,
            "wins": wins,
            "losses": losses,
            "last_action": primary_event.get("action", "HOLD"),
            "last_price": price,
            "positions": positions,
            "recent_exits": recent_exits,
            "history": history,
            "last_regime": regime,
            "profile": profile_key,
            "hybrid_weight": round(hybrid_weight, 6),
            "breadth_pos_pct24": round(breadth, 6),
            "last_candidates": picks,
            "scan_count": scored.get("scan_count", 0),
            "scan_target": int(max_scan),
            "scored_count": scored.get("scored_count", 0),
            "venue_counts": venue_counts,
            "base_risk_fraction": round(base_risk, 6),
            "max_positions": int(max_positions),
            "capital_tank": {
                "cash_usd": round(cash, 6),
                "equity_usd": round(equity, 6),
                "heat_pct": round((gross_position_value / equity) if equity > 0 else 0.0, 6),
                "deployable_cash_pct": round((cash / equity) if equity > 0 else 0.0, 6),
                "positions_open": len(positions),
            },
            "adaptive_tuning": {
                "event": tune_event,
                "totals_n": _i(totals.get("n"), 0),
                "totals_win_rate": round(_f(totals.get("win_rate"), 0.0), 6),
                "totals_profit_factor": round(_f(totals.get("profit_factor"), 0.0), 6),
                "base_risk_fraction": round(base_risk, 6),
                "max_positions": int(max_positions),
            },
            "scientific_allocator": {
                "mode": allocator_mode,
                "optimizer_ok": bool(optimizer_result.get("ok", False)) if isinstance(optimizer_result, dict) else False,
                "optimizer_status": str(optimizer_result.get("status", "n/a")) if isinstance(optimizer_result, dict) else "n/a",
                "optimizer_solver": optimizer_result.get("solver") if isinstance(optimizer_result, dict) else None,
                "optimizer_risk_aversion": round(optimizer_risk_aversion, 6),
                "optimizer_turnover_penalty": round(optimizer_turnover_penalty, 6),
                "max_single_position_pct": round(max_single_position_pct, 6),
                "max_gross_heat_pct": round(max_gross_heat_pct, 6),
                "target_position_vol_pct": round(target_position_vol_pct, 6),
                "uncertainty_penalty_k": round(uncertainty_penalty_k, 6),
                "min_diversified_slots": int(min_diversified_slots),
                "vol_scalar_floor": round(vol_scalar_floor, 6),
                "vol_scalar_ceiling": round(vol_scalar_ceiling, 6),
                "equity_basis_usd": round(equity_basis, 6),
                "available_heat_pct": round(available_heat_pct, 6),
                "current_heat_pct": round((gross_position_value / equity) if equity > 0 else 0.0, 6),
                "current_gross_heat_usd": round(gross_position_value, 6),
                "last_target_weights": {str(k): round(_f(v, 0.0), 6) for k, v in optimized_weights.items()},
            },
            "regime_controller": regime_controller,
            "quality_gate": {
                "entry_mode": str(preset.get("entry_mode", "risk_budget")),
                "min_edge": round(gate_min_edge, 6),
                "min_pct24": round(gate_min_pct24, 6),
                "max_pct24": round(gate_max_pct24, 6),
                "min_quote_volume_usd": round(gate_min_qv, 2),
                "min_near_high": round(gate_min_near_high, 6),
                "min_r2": round(gate_min_r2, 6),
                "reentry_cooldown_cycles": int(gate_reentry_cooldown),
                "rejections": gate_rejects,
            },
        }
    )

    save_json(BINANCEUS_PAPER_STATE_FILE, state)

    return {
        "ok": True,
        "state_file": str(BINANCEUS_PAPER_STATE_FILE),
        "ledger_file": str(BINANCEUS_PAPER_LEDGER_FILE),
        "event": primary_event,
        "events_count": len(events),
        "state": state,
        "regime": regime,
        "profile": profile_key,
        "hybrid_weight": hybrid_weight,
        "breadth_pos_pct24": breadth,
        "scan_count": scored.get("scan_count", 0),
        "scan_target": int(max_scan),
        "scored_count": scored.get("scored_count", 0),
        "venue_counts": venue_counts,
        "moon_top": moon_top[:5],
        "fallback_top": fallback_top[:5],
        "hybrid_top": hybrid_ranked[:5],
        "quality_gate": {
            "entry_mode": str(preset.get("entry_mode", "risk_budget")),
            "min_edge": gate_min_edge,
            "min_pct24": gate_min_pct24,
            "max_pct24": gate_max_pct24,
            "min_quote_volume_usd": gate_min_qv,
            "min_near_high": gate_min_near_high,
            "min_r2": gate_min_r2,
            "reentry_cooldown_cycles": gate_reentry_cooldown,
            "rejections": gate_rejects,
        },
        "scientific_allocator": state.get("scientific_allocator", {}),
        "regime_controller": state.get("regime_controller", {}),
        "scoreboard_file": str(BINANCEUS_PAPER_SCOREBOARD_FILE),
        "scoreboard_totals": totals,
    }


def alpaca_snapshot() -> Dict[str, Any]:
    key = os.getenv("ALPACA_API_KEY", "").strip()
    secret = os.getenv("ALPACA_API_SECRET", "").strip()
    base = os.getenv("ALPACA_PAPER_BASE_URL", "").strip() or os.getenv("ALPACA_BASE_URL", "").strip() or "https://paper-api.alpaca.markets"

    if not key or not secret:
        return {"ok": False, "error": "Missing ALPACA_API_KEY/ALPACA_API_SECRET", "base_url": base}

    headers = {
        "APCA-API-KEY-ID": key,
        "APCA-API-SECRET-KEY": secret,
    }
    res = _get(f"{base}/v2/account", headers=headers, timeout=12)
    if not res.get("ok"):
        return {"ok": False, "base_url": base, "error": res.get("error")}
    data = res.get("data", {})

    def _f(v: Any) -> float | None:
        try:
            return float(v)
        except Exception:
            return None

    return {
        "ok": True,
        "base_url": base,
        "status": data.get("status"),
        "equity": _f(data.get("equity")),
        "cash": _f(data.get("cash")),
        "buying_power": _f(data.get("buying_power")),
    }


def run_alpaca_builder(python_exe: str) -> Dict[str, Any]:
    script = CODE / "alpaca_paper_loop_builder.py"
    if not script.exists():
        return {"ok": False, "error": f"Missing script: {script}"}

    try:
        proc = subprocess.run(
            [python_exe, str(script)],
            cwd=str(CODE),
            capture_output=True,
            text=True,
            check=False,
        )
        return {
            "ok": proc.returncode == 0,
            "return_code": proc.returncode,
            "stdout_tail": (proc.stdout or "").splitlines()[-6:],
            "stderr_tail": (proc.stderr or "").splitlines()[-6:],
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def run_institutional_crypto_dashboard_builder(python_exe: str) -> Dict[str, Any]:
    script = CODE / "execution" / "build_institutional_crypto_paper_dashboard.py"
    if not script.exists():
        return {"ok": False, "error": f"Missing script: {script}"}

    try:
        proc = subprocess.run(
            [python_exe, str(script)],
            cwd=str(CODE),
            capture_output=True,
            text=True,
            check=False,
        )
        return {
            "ok": proc.returncode == 0,
            "return_code": proc.returncode,
            "stdout_tail": (proc.stdout or "").splitlines()[-6:],
            "stderr_tail": (proc.stderr or "").splitlines()[-6:],
            "dashboard_file": str(INSTITUTIONAL_PAPER_DASHBOARD_FILE),
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc), "dashboard_file": str(INSTITUTIONAL_PAPER_DASHBOARD_FILE)}


def run_institutional_crypto_brief_builder(python_exe: str) -> Dict[str, Any]:
    script = CODE / "execution" / "build_institutional_crypto_executive_brief.py"
    if not script.exists():
        return {"ok": False, "error": f"Missing script: {script}"}

    try:
        proc = subprocess.run(
            [python_exe, str(script)],
            cwd=str(CODE),
            capture_output=True,
            text=True,
            check=False,
        )
        return {
            "ok": proc.returncode == 0,
            "return_code": proc.returncode,
            "stdout_tail": (proc.stdout or "").splitlines()[-8:],
            "stderr_tail": (proc.stderr or "").splitlines()[-8:],
            "brief_file": str(INSTITUTIONAL_PAPER_BRIEF_FILE),
        }
    except Exception as exc:
        return {"ok": False, "error": str(exc), "brief_file": str(INSTITUTIONAL_PAPER_BRIEF_FILE)}


def tick(python_exe: str, cycle: int, profile: str, seed_capital: float, reset_state: bool = False) -> Dict[str, Any]:
    hydrate = hydrate_live_keys()
    runtime_guard = force_paper_mode()

    kraken = kraken_snapshot()
    binance = binance_snapshot("https://api.binance.com")
    binanceus = binance_snapshot("https://api.binance.us")
    binanceus_private = binanceus_private_account_snapshot()
    binanceus_paper = run_binanceus_paper_logic(binanceus.get("price"), cycle, profile, seed_capital, reset_state=reset_state)
    alpaca = alpaca_snapshot()
    builder = run_alpaca_builder(python_exe)

    payload = {
        "timestamp_utc": now_utc(),
        "cycle": cycle,
        "profile": profile,
        "seed_capital_usd": round(max(seed_capital, 1000.0), 6),
        "reset_state": bool(reset_state),
        "runtime_guard": runtime_guard,
        "hydrate": hydrate,
        "exchanges": {
            "kraken": kraken,
            "binance": binance,
            "binanceus": binanceus,
            "binanceus_private": binanceus_private,
            "alpaca_paper": alpaca,
        },
        "binanceus_paper_engine": binanceus_paper,
        "alpaca_builder": builder,
    }
    save_json(STATUS_FILE, payload)
    append_jsonl(LEDGER_FILE, payload)
    payload["institutional_crypto_paper_report"] = build_institutional_crypto_paper_report(payload, seed_capital, reset_state)
    payload["institutional_crypto_dashboard"] = run_institutional_crypto_dashboard_builder(python_exe)
    payload["institutional_crypto_brief"] = run_institutional_crypto_brief_builder(python_exe)
    save_json(STATUS_FILE, payload)
    return payload


def pretty_tick(payload: Dict[str, Any]) -> str:
    ts = payload.get("timestamp_utc", "")
    cycle = payload.get("cycle", "?")
    ex = payload.get("exchanges", {})

    def fmt(name: str, key: str = "price") -> str:
        item = ex.get(name, {}) if isinstance(ex, dict) else {}
        if not isinstance(item, dict):
            return f"{name}=ERR"
        if item.get("ok"):
            val = item.get(key)
            return f"{name}={val}"
        return f"{name}=ERR"

    return (
        f"[PAPER-TICK] {ts} cycle={cycle} "
        f"profile={payload.get('profile')} "
        f"seed={payload.get('seed_capital_usd')} "
        f"{fmt('kraken')} {fmt('binance')} {fmt('binanceus')} "
        f"bus_priv_ok={ex.get('binanceus_private', {}).get('ok')} "
        f"bus_regime={payload.get('binanceus_paper_engine', {}).get('regime')} "
        f"bus_scan={payload.get('binanceus_paper_engine', {}).get('scan_count')} "
        f"bus_scored={payload.get('binanceus_paper_engine', {}).get('scored_count')} "
        f"bus_open={len(payload.get('binanceus_paper_engine', {}).get('state', {}).get('positions', {}))} "
        f"bus_paper_eq={payload.get('binanceus_paper_engine', {}).get('state', {}).get('equity_usd')} "
        f"bus_last={payload.get('binanceus_paper_engine', {}).get('event', {}).get('action')} "
        f"alpaca_equity={ex.get('alpaca_paper', {}).get('equity')} "
        f"builder_ok={payload.get('alpaca_builder', {}).get('ok')}"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Multi-exchange live-ticking paper supervisor")
    parser.add_argument("--interval", type=float, default=5.0, help="Seconds between cycles")
    parser.add_argument("--cycles", type=int, default=0, help="0 means run forever")
    parser.add_argument("--profile", type=str, default=DEFAULT_PROFILE, choices=sorted(PROFILE_PRESETS.keys()), help="Execution profile preset")
    parser.add_argument("--seed-capital", type=float, default=10000.0, help="Initial paper capital when creating or resetting state")
    parser.add_argument("--reset-paper-state", action="store_true", help="Reset paper state to the requested seeded capital before the next cycle")
    args = parser.parse_args()

    lock_ok, lock_msg = acquire_single_instance_lock(args.profile)
    if not lock_ok:
        print(f"[LOCK] multi_exchange_paper_ticker already running ({lock_msg})", flush=True)
        return 1
    atexit.register(release_single_instance_lock)

    python_exe = sys.executable
    count = 0
    while True:
        if not is_current_lock_owner():
            print("[LOCK] lock ownership lost; exiting duplicate/non-owner process", flush=True)
            return 1

        count += 1
        payload = tick(python_exe, count, args.profile, args.seed_capital, reset_state=(args.reset_paper_state and count == 1))
        print(pretty_tick(payload), flush=True)

        if args.cycles > 0 and count >= args.cycles:
            break
        time.sleep(max(float(args.interval), 1.0))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())