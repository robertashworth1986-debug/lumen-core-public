from dataclasses import dataclass


@dataclass
class SizeInput:
    equity_usd: float
    entry_price: float
    stop_price: float
    realized_vol: float
    edge_score: float
    portfolio_heat: float
    liquidity_score: float = 1.0  # added


@dataclass
class SizeDecision:
    qty: float
    notional_usd: float
    risk_usd: float
    leverage_hint: float


class SizingEngine:
    def __init__(
        self,
        max_risk_pct: float = 0.0035,
        max_heat: float = 0.02,
        vol_target: float = 0.15,
    ):
        self.max_risk_pct = max_risk_pct
        self.max_heat = max_heat
        self.vol_target = vol_target

    def size(self, x: SizeInput) -> SizeDecision:
        equity = max(float(x.equity_usd), 0.0)
        entry = max(float(x.entry_price), 1e-9)
        stop = max(float(x.stop_price), 1e-9)

        stop_dist = abs(entry - stop)
        if stop_dist <= 1e-9 or equity <= 0:
            return SizeDecision(qty=0.0, notional_usd=0.0, risk_usd=0.0, leverage_hint=1.0)

        # base risk budget
        risk_usd = equity * self.max_risk_pct

        # heat haircut
        heat_ratio = min(max(x.portfolio_heat / max(self.max_heat, 1e-9), 0.0), 2.0)
        heat_haircut = max(0.15, 1.0 - 0.5 * heat_ratio)

        # liquidity haircut
        liq = min(max(float(x.liquidity_score), 0.0), 1.0)
        liq_haircut = max(0.15, liq)

        # edge boost
        edge = min(max(float(x.edge_score), 0.0), 1.0)
        edge_boost = 0.35 + (1.40 * edge)  # ~0.35 to 1.75

        # vol scaling
        rv = max(float(x.realized_vol), 1e-6)
        vol_scale = min(max(self.vol_target / rv, 0.25), 2.0)

        adj_risk = risk_usd * heat_haircut * liq_haircut * edge_boost * vol_scale
        qty = max(adj_risk / stop_dist, 0.0)
        notional = qty * entry

        leverage_hint = min(max(vol_scale, 0.5), 3.0)
        return SizeDecision(qty=qty, notional_usd=notional, risk_usd=adj_risk, leverage_hint=leverage_hint)
